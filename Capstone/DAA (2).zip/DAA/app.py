"""
NP-Complete Problem Visualizer & Solver - Flask Backend Server
Design and Analysis of Algorithms (DAA) Project
"""

import os
import json
import io
import csv
from flask import Flask, request, jsonify, send_file, send_from_directory
from werkzeug.exceptions import BadRequest

from engine.benchmark import run_benchmarked_solver
from engine.growth_analyzer import run_growth_analysis
from engine.history_store import HistoryStore
from reports.pdf_generator import generate_pdf_report

app = Flask(__name__, static_folder="static", static_url_path="")
history_store = HistoryStore("history.db")

# Load sample data
SAMPLES_FILE = os.path.join(os.path.dirname(__file__), "sample_data", "samples.json")
samples_data = {}
if os.path.exists(SAMPLES_FILE):
    with open(SAMPLES_FILE, "r", encoding="utf-8") as f:
        samples_data = json.load(f)


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/api/samples", methods=["GET"])
def get_samples():
    """Returns pre-loaded benchmark sample instances"""
    return jsonify(samples_data)


@app.route("/api/stats", methods=["GET"])
def get_stats():
    """Returns dashboard summary statistics"""
    stats = history_store.get_summary_stats()
    return jsonify(stats)


@app.route("/api/solve", methods=["POST"])
def solve():
    """
    Executes a single algorithm solver on given problem inputs.
    Returns step-by-step telemetry, performance metrics, data structures, and solution.
    """
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Missing JSON request body."}), 400

    problem = data.get("problem")
    algorithm = data.get("algorithm")
    params = data.get("params", {})
    max_steps = int(data.get("max_steps", 2500))
    record_history = data.get("record_history", True)

    if not problem or not algorithm:
        return jsonify({"error": "Both 'problem' and 'algorithm' fields are required."}), 400

    try:
        result = run_benchmarked_solver(problem, algorithm, params, max_steps=max_steps)
        
        # Save to persistent history if requested
        if record_history:
            history_id = history_store.record_execution(problem, algorithm, params, result)
            result["history_id"] = history_id

        return jsonify(result)

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": f"Internal algorithm execution error: {str(e)}"}), 500


@app.route("/api/compare", methods=["POST"])
def compare():
    """
    Executes multiple algorithms on identical problem instance parameters.
    Returns side-by-side performance benchmarks and comparative metrics.
    """
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Missing JSON request body."}), 400

    problem = data.get("problem")
    algorithms = data.get("algorithms", [])
    params = data.get("params", {})

    if not problem or not algorithms:
        return jsonify({"error": "Problem and a non-empty list of algorithms are required."}), 400

    results = []
    errors = []

    for algo in algorithms:
        try:
            res = run_benchmarked_solver(problem, algo, params, max_steps=100)
            # Remove lengthy step array to optimize payload for comparison view
            if "steps" in res:
                res["steps_count"] = len(res["steps"])
                del res["steps"]
            results.append(res)
        except Exception as e:
            errors.append({"algorithm": algo, "error": str(e)})

    # Calculate fastest algorithm
    fastest_algo = None
    min_time = float("inf")
    for r in results:
        t = r["statistics"]["execution_time_ms"]
        if t < min_time:
            min_time = t
            fastest_algo = r["algorithm_name"]

    return jsonify({
        "problem": problem,
        "results": results,
        "errors": errors,
        "comparison_summary": {
            "algorithms_evaluated": len(results),
            "fastest_algorithm": fastest_algo,
            "fastest_time_ms": min_time if min_time != float("inf") else 0
        }
    })


@app.route("/api/growth", methods=["POST"])
def growth():
    """
    Runs empirical scalability growth analysis across increasing input sizes.
    """
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Missing JSON request body."}), 400

    problem = data.get("problem")
    algorithms = data.get("algorithms", [])
    input_sizes = data.get("input_sizes", [4, 6, 8, 10, 12])

    if not problem or not algorithms:
        return jsonify({"error": "Problem and algorithms are required."}), 400

    try:
        growth_data = run_growth_analysis(problem, algorithms, input_sizes)
        return jsonify(growth_data)
    except Exception as e:
        return jsonify({"error": f"Growth analysis failed: {str(e)}"}), 500


@app.route("/api/history", methods=["GET"])
def get_history():
    """Retrieves execution history with optional filtering and search"""
    problem = request.args.get("problem", "all")
    algorithm = request.args.get("algorithm", "all")
    search_query = request.args.get("search", "")
    limit = int(request.args.get("limit", 100))
    offset = int(request.args.get("offset", 0))

    runs = history_store.get_executions(
        problem=problem, algorithm=algorithm, search_query=search_query, limit=limit, offset=offset
    )
    return jsonify({"history": runs})


@app.route("/api/history/<int:exec_id>", methods=["GET"])
def get_history_detail(exec_id):
    """Retrieves full detail of a specific past execution"""
    run = history_store.get_execution_detail(exec_id)
    if not run:
        return jsonify({"error": "Execution record not found."}), 404
    return jsonify(run)


@app.route("/api/history/<int:exec_id>", methods=["DELETE"])
def delete_history_item(exec_id):
    """Deletes a specific history record"""
    deleted = history_store.delete_execution(exec_id)
    if not deleted:
        return jsonify({"error": "Record not found."}), 404
    return jsonify({"success": True})


@app.route("/api/history/clear", methods=["POST"])
def clear_history():
    """Clears all stored execution history"""
    history_store.clear_history()
    return jsonify({"success": True, "message": "History database cleared successfully."})


@app.route("/api/report/pdf", methods=["POST"])
def generate_report():
    """
    Generates and downloads a publication-grade PDF report for the project.
    """
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Missing report payload data."}), 400

    try:
        pdf_bytes = generate_pdf_report(data)
        return send_file(
            io.BytesIO(pdf_bytes),
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"DAA_NP_Complete_Report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        )
    except Exception as e:
        return jsonify({"error": f"Failed to generate PDF report: {str(e)}"}), 500


@app.route("/api/upload-validate", methods=["POST"])
def upload_validate():
    """
    Accepts uploaded dataset files (.json, .csv, .txt) and parses them into problem input parameters.
    """
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400

    file = request.files["file"]
    problem = request.form.get("problem", "")

    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    filename = file.filename.lower()
    content = file.read().decode("utf-8", errors="ignore")

    try:
        if filename.endswith(".json"):
            parsed = json.loads(content)
            # Validate structure according to problem
            if problem == "knapsack":
                if "weights" not in parsed or "values" not in parsed or "capacity" not in parsed:
                    return jsonify({"error": "JSON for Knapsack must contain 'weights', 'values', and 'capacity'."}), 400
            elif problem == "tsp":
                if "matrix" not in parsed:
                    return jsonify({"error": "JSON for TSP must contain 'matrix' (2D array)."}), 400
            elif problem == "subset_sum":
                if "numbers" not in parsed or "target" not in parsed:
                    return jsonify({"error": "JSON for Subset Sum must contain 'numbers' and 'target'."}), 400
            elif problem == "nqueens":
                if "n" not in parsed:
                    return jsonify({"error": "JSON for N-Queens must contain 'n'."}), 400
            return jsonify({"success": True, "params": parsed})

        elif filename.endswith(".csv"):
            reader = csv.reader(io.StringIO(content))
            rows = [r for r in reader if r and not r[0].startswith("#")]
            
            if problem == "knapsack":
                # Expecting columns: weight, value (row 1 header optional)
                weights, values = [], []
                for row in rows:
                    if len(row) >= 2:
                        try:
                            weights.append(int(float(row[0].strip())))
                            values.append(int(float(row[1].strip())))
                        except ValueError:
                            continue
                if not weights:
                    return jsonify({"error": "No valid numeric rows found in CSV."}), 400
                capacity = int(sum(weights) * 0.5)
                return jsonify({"success": True, "params": {"weights": weights, "values": values, "capacity": capacity}})

            elif problem == "tsp":
                # CSV matrix
                matrix = []
                for row in rows:
                    numeric_row = []
                    for val in row:
                        try:
                            numeric_row.append(int(float(val.strip())))
                        except ValueError:
                            pass
                    if numeric_row:
                        matrix.append(numeric_row)
                if len(matrix) < 3:
                    return jsonify({"error": "TSP CSV matrix must have at least 3 rows."}), 400
                return jsonify({"success": True, "params": {"matrix": matrix}})

            elif problem == "subset_sum":
                numbers = []
                for row in rows:
                    for val in row:
                        try:
                            numbers.append(int(float(val.strip())))
                        except ValueError:
                            pass
                if not numbers:
                    return jsonify({"error": "No numbers found in CSV."}), 400
                target = int(sum(numbers) * 0.4)
                return jsonify({"success": True, "params": {"numbers": numbers, "target": target}})

            elif problem == "nqueens":
                n_val = int(rows[0][0].strip()) if rows and rows[0] else 8
                return jsonify({"success": True, "params": {"n": n_val}})

        elif filename.endswith(".txt"):
            lines = [line.strip() for line in content.splitlines() if line.strip() and not line.startswith("#")]
            if problem == "knapsack":
                # First line: capacity; subsequent lines: weight value
                capacity = int(lines[0])
                weights, values = [], []
                for line in lines[1:]:
                    parts = line.split()
                    if len(parts) >= 2:
                        weights.append(int(parts[0]))
                        values.append(int(parts[1]))
                return jsonify({"success": True, "params": {"weights": weights, "values": values, "capacity": capacity}})

            elif problem == "subset_sum":
                # First line: target; subsequent lines: numbers
                target = int(lines[0])
                numbers = [int(p) for line in lines[1:] for p in line.split()]
                return jsonify({"success": True, "params": {"numbers": numbers, "target": target}})

            elif problem == "nqueens":
                n_val = int(lines[0])
                return jsonify({"success": True, "params": {"n": n_val}})

            elif problem == "tsp":
                matrix = []
                for line in lines:
                    matrix.append([int(x) for x in line.split()])
                return jsonify({"success": True, "params": {"matrix": matrix}})

        return jsonify({"error": f"Unsupported file format '{filename}'. Please upload .json, .csv, or .txt."}), 400

    except Exception as e:
        return jsonify({"error": f"Failed to parse dataset file: {str(e)}"}), 400


import datetime

if __name__ == "__main__":
    print("=" * 70)
    print("  NP-Complete Problem Visualizer & Solver (DAA B.Tech Project)")
    print("  Server running on http://127.0.0.1:5000")
    print("=" * 70)
    app.run(host="127.0.0.1", port=5000, debug=True)
