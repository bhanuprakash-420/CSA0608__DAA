"""
Integration Tests for Flask API Endpoints
"""

import sys
import os
import unittest
import json
import io

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import app, history_store


class TestAPIEndpoints(unittest.TestCase):

    def setUp(self):
        self.client = app.test_client()

    def test_get_index(self):
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'NP-Complete Visualizer & Solver', res.data)

    def test_get_samples(self):
        res = self.client.get('/api/samples')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('knapsack', data)
        self.assertIn('tsp', data)
        self.assertIn('subset_sum', data)
        self.assertIn('nqueens', data)

    def test_get_stats(self):
        res = self.client.get('/api/stats')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('problems_supported', data)

    def test_solve_knapsack_api(self):
        payload = {
            "problem": "knapsack",
            "algorithm": "dynamic_programming",
            "params": {
                "weights": [10, 20, 30],
                "values": [60, 100, 120],
                "capacity": 50
            }
        }
        res = self.client.post('/api/solve', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["solution"]["total_value"], 220)
        self.assertIn("steps", data)
        self.assertIn("statistics", data)

    def test_solve_tsp_api(self):
        payload = {
            "problem": "tsp",
            "algorithm": "branch_and_bound",
            "params": {
                "matrix": [
                    [0, 10, 15, 20],
                    [10, 0, 35, 25],
                    [15, 35, 0, 30],
                    [20, 25, 30, 0]
                ]
            }
        }
        res = self.client.post('/api/solve', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["solution"]["total_distance"], 80)

    def test_compare_api(self):
        payload = {
            "problem": "subset_sum",
            "algorithms": ["dynamic_programming", "backtracking", "branch_and_bound"],
            "params": {
                "numbers": [10, 7, 5, 18, 12],
                "target": 35
            }
        }
        res = self.client.post('/api/compare', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(len(data["results"]), 3)
        self.assertIn("comparison_summary", data)

    def test_growth_api(self):
        payload = {
            "problem": "nqueens",
            "algorithms": ["backtracking", "branch_and_bound"],
            "input_sizes": [4, 6]
        }
        res = self.client.post('/api/growth', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("series", data)

    def test_history_api(self):
        res = self.client.get('/api/history')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("history", data)

    def test_pdf_report_api(self):
        payload = {
            "problem": "0/1 Knapsack",
            "problem_name": "0/1 Knapsack",
            "algorithm_name": "Dynamic Programming",
            "is_optimal": True,
            "statistics": {"execution_time_ms": 0.45, "memory_kb": 12.4, "states_explored": 45, "states_pruned": 0},
            "input_params": {"weights": [10, 20, 30], "values": [60, 100, 120], "capacity": 50},
            "solution": {"total_value": 220, "total_weight": 50}
        }
        res = self.client.post('/api/report/pdf', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, 'application/pdf')

    def test_upload_validate_json_api(self):
        file_content = json.dumps({"weights": [5, 10, 15], "values": [20, 40, 60], "capacity": 25}).encode('utf-8')
        data = {
            'file': (io.BytesIO(file_content), 'test_knapsack.json'),
            'problem': 'knapsack'
        }
        res = self.client.post('/api/upload-validate', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 200)
        parsed = res.get_json()
        self.assertTrue(parsed["success"])
        self.assertEqual(parsed["params"]["capacity"], 25)


if __name__ == "__main__":
    unittest.main()
