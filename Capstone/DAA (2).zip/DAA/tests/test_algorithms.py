"""
Unit and Integration Tests for NP-Complete Solvers and Benchmarks
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from algorithms.knapsack import solve_knapsack
from algorithms.tsp import solve_tsp
from algorithms.subset_sum import solve_subset_sum
from algorithms.nqueens import solve_nqueens
from engine.benchmark import run_benchmarked_solver
from engine.growth_analyzer import run_growth_analysis
from reports.pdf_generator import generate_pdf_report


class TestDAAAlgorithms(unittest.TestCase):

    def test_knapsack_dp(self):
        w = [10, 20, 30]
        v = [60, 100, 120]
        cap = 50
        res = solve_knapsack(w, v, cap, algorithm="dynamic_programming")
        self.assertEqual(res["solution"]["total_value"], 220)
        self.assertTrue(res["is_optimal"])
        self.assertTrue(len(res["steps"]) > 0)

    def test_knapsack_bnb_and_backtracking(self):
        w = [10, 20, 30]
        v = [60, 100, 120]
        cap = 50
        res_bt = solve_knapsack(w, v, cap, algorithm="backtracking")
        res_bnb = solve_knapsack(w, v, cap, algorithm="branch_and_bound")
        self.assertEqual(res_bt["solution"]["total_value"], 220)
        self.assertEqual(res_bnb["solution"]["total_value"], 220)
        self.assertTrue(res_bnb["statistics"]["states_pruned"] >= 0)

    def test_tsp_backtracking_and_bnb(self):
        mat = [
            [0, 10, 15, 20],
            [10, 0, 35, 25],
            [15, 35, 0, 30],
            [20, 25, 30, 0]
        ]
        res_bt = solve_tsp(mat, algorithm="backtracking")
        res_bnb = solve_tsp(mat, algorithm="branch_and_bound")
        res_greedy = solve_tsp(mat, algorithm="greedy")
        res_2opt = solve_tsp(mat, algorithm="two_opt")

        self.assertEqual(res_bt["solution"]["total_distance"], 80)
        self.assertEqual(res_bnb["solution"]["total_distance"], 80)
        self.assertTrue(res_greedy["solution"]["total_distance"] >= 80)
        self.assertTrue(res_2opt["solution"]["total_distance"] >= 80)

    def test_subset_sum_dp_and_bt(self):
        nums = [10, 7, 5, 18, 12]
        target = 35  # 10 + 7 + 18 = 35 or 18 + 12 + 5 = 35
        res_dp = solve_subset_sum(nums, target, algorithm="dynamic_programming")
        res_bt = solve_subset_sum(nums, target, algorithm="backtracking")
        res_bnb = solve_subset_sum(nums, target, algorithm="branch_and_bound")

        self.assertTrue(res_dp["solution"]["is_achievable"])
        self.assertTrue(res_bt["solution"]["is_achievable"])
        self.assertTrue(res_bnb["solution"]["is_achievable"])
        self.assertEqual(res_dp["solution"]["achieved_sum"], 35)

    def test_nqueens(self):
        res_bt = solve_nqueens(4, algorithm="backtracking")
        res_bnb = solve_nqueens(4, algorithm="branch_and_bound")

        self.assertTrue(res_bt["solution"]["has_solution"])
        self.assertTrue(res_bnb["solution"]["has_solution"])
        # For N=4, board should be [1, 3, 0, 2] or [2, 0, 3, 1]
        self.assertEqual(len(res_bt["solution"]["solution_board"]), 4)

    def test_benchmarking_engine(self):
        params = {"weights": [10, 20, 30], "values": [60, 100, 120], "capacity": 50}
        res = run_benchmarked_solver("knapsack", "dynamic_programming", params)
        self.assertIn("execution_time_ms", res["statistics"])
        self.assertIn("memory_kb", res["statistics"])

    def test_growth_analysis(self):
        res = run_growth_analysis("nqueens", ["backtracking", "branch_and_bound"], [4, 6])
        self.assertEqual(len(res["series"]["backtracking"]), 2)

    def test_pdf_report_generation(self):
        payload = {
            "problem": "0/1 Knapsack",
            "problem_name": "0/1 Knapsack",
            "algorithm_name": "Dynamic Programming",
            "is_optimal": True,
            "statistics": {"execution_time_ms": 0.45, "memory_kb": 12.4, "states_explored": 45, "states_pruned": 0},
            "input_params": {"weights": [10, 20, 30], "values": [60, 100, 120], "capacity": 50},
            "solution": {"total_value": 220, "total_weight": 50}
        }
        pdf_bytes = generate_pdf_report(payload)
        self.assertTrue(len(pdf_bytes) > 500)
        self.assertTrue(pdf_bytes.startswith(b"%PDF"))


if __name__ == "__main__":
    unittest.main()
