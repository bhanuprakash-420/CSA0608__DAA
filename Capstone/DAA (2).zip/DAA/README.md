# NP-Complete Problem Visualizer and Solver Using Efficient Algorithmic Techniques

> **B.Tech Design and Analysis of Algorithms (DAA) Academic Project**  
> *An interactive, educational visualization and performance benchmarking platform for NP-Complete and NP-Hard problems.*

---

## 📌 Project Overview

This project provides a full-featured web application to simulate, visualize step-by-step, benchmark, and compare efficient algorithmic techniques across fundamental NP-Complete / NP-Hard problems:

1. **0/1 Knapsack Problem** (Resource Allocation & Budgeting)
2. **Travelling Salesman Problem (TSP)** (Route Optimization & Graph Cycles)
3. **Subset Sum Problem** (Subset Selection & Target Reconciliations)
4. **N-Queens Problem** (Constraint Satisfaction & Chessboard Configuration)

---

## 🚀 Key Features

* **Interactive Step-by-Step Visualization**:
  * **Search Tree Visualizer**: State-space decision trees for Backtracking and Branch & Bound with active node pulses, pruned branch indicators (scissor icons & reasons), and optimal path highlighting.
  * **DP Matrix Visualizer**: Dynamic 2D tabulation grid with live recurrence formula tooltips and optimal item backtrack path tracing.
  * **TSP 2D Graph Visualizer**: Animated tour traversal on a Euclidean coordinate plane, distance weights on pairwise edges, and shortest tour highlighting.
  * **N-Queens Chessboard**: $N \times N$ interactive board with conflict laser rays and forward-checking domain lookahead pruning.
  * **Greedy Candidate Queue**: Ratio sorting, item pick/reject cards, and capacity consumption bars.
* **True Algorithmic Solvers (13 Algorithm Variants)**:
  * Dynamic Programming
  * Backtracking (Depth-First Search with constraint pruning)
  * Branch and Bound (Fractional Knapsack upper bounds, TSP 1-Tree bounds, N-Queens Forward Checking)
  * Greedy Heuristics (Density Ratio sorting, Nearest Neighbor)
  * Approximation Algorithms (2-Opt Local Search)
* **Real-time Performance Benchmarking**:
  * High-resolution hardware timing via `time.perf_counter_ns` (microseconds & milliseconds).
  * Peak memory allocation measurement via Python `tracemalloc`.
  * Node generation, states explored vs pruned metrics.
* **Multi-Algorithm Comparison Suite**:
  * Side-by-side execution on identical instances.
  * Interactive Chart.js bar graphs (Execution Time, Memory, Explored vs Pruned States).
* **Input Scalability & Growth Lab**:
  * Plots empirical input size ($N$) vs execution time curves to visually prove exponential $O(2^N)$ and factorial $O(N!)$ growth vs polynomial heuristics.
* **Persistent Execution History**:
  * SQLite database logging all past runs with search, filtering, and JSON export.
* **Publication-Grade PDF Report Generation**:
  * One-click download of styled academic project reports using ReportLab with tables, complexity breakdown, and conclusions.

---

## 🛠️ Technology Stack

* **Backend**: Python 3.14 + Flask
* **Algorithms**: Pure Python 3 (Optimized exact recursion, bounding, and DP matrix operations)
* **Benchmarking**: `time.perf_counter_ns`, `tracemalloc`
* **Reports**: ReportLab PDF Engine
* **Frontend**: Vanilla ES6+ JavaScript, Tailwind CSS (Dark Modern Theme), FontAwesome 6, Chart.js, HTML5 Canvas & SVG

---

## 📂 Project Structure

```
DAA/
├── app.py                     # Flask server & REST API endpoints
├── run.bat                    # One-click Windows launch script
├── requirements.txt           # Python dependencies
├── algorithms/                # Algorithmic solvers with step telemetry
│   ├── __init__.py
│   ├── knapsack.py            # DP, Backtracking, Branch & Bound, Greedy
│   ├── tsp.py                 # Backtracking, Branch & Bound, Nearest Neighbor, 2-Opt
│   ├── subset_sum.py          # DP, Backtracking, Branch & Bound
│   └── nqueens.py             # Backtracking, Forward Checking Branch & Bound
├── engine/                    # Benchmarking & analysis engine
│   ├── __init__.py
│   ├── benchmark.py           # Nanosecond timer & tracemalloc memory tracker
│   ├── growth_analyzer.py     # Input scalability runner
│   └── history_store.py       # SQLite persistent database
├── reports/                   # Academic PDF report generator
│   ├── __init__.py
│   └── pdf_generator.py       # ReportLab PDF styling
├── sample_data/               # Benchmark datasets (JSON)
│   └── samples.json
├── static/                    # Frontend assets
│   ├── index.html             # Single-page dashboard application
│   ├── css/
│   │   └── custom.css         # Dark theme, glassmorphism, animations
│   └── js/
│       ├── api.js             # Fetch client for backend endpoints
│       ├── state.js           # Reactive application state
│       ├── visualizers/
│       │   ├── tree_visualizer.js       # Search Tree Visualizer (Canvas)
│       │   ├── dp_visualizer.js         # DP Table Matrix Visualizer
│       │   ├── tsp_visualizer.js        # TSP 2D Graph Visualizer
│       │   ├── chessboard_visualizer.js # N-Queens Chessboard
│       │   ├── greedy_visualizer.js     # Greedy Queue Visualizer
│       │   └── data_structure_visualizer.js
│       ├── comparison.js      # Multi-algorithm comparison & charts
│       ├── growth.js          # Growth curves & Chart.js plots
│       ├── history.js         # History table, search & export
│       └── app.js             # Main controller & stepper engine
└── tests/                     # Unit and integration test suite
    ├── test_algorithms.py
    └── test_api_endpoints.py
```

---

## 🏃 How to Run Locally

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Launch the Application Server
Double-click `run.bat` or run:
```bash
python app.py
```

### 3. Open in Browser
Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🧪 Running Automated Tests
```bash
python tests/test_algorithms.py
python tests/test_api_endpoints.py
```

---

## 🎓 College Viva & Demonstration Flow

1. **Open Dashboard**: View global metrics, quick-launch cards, and project workflow.
2. **Select Problem**: Choose e.g., **Travelling Salesman Problem (TSP)** or **0/1 Knapsack**.
3. **Choose Input**: Select a benchmark preset (e.g. Classic Textbook 4-Items) or click *Random Instance*.
4. **Choose Algorithm**: Select **Branch and Bound**.
5. **Click RUN ALGORITHM**: Observe the instant execution, solution metrics, and memory measurement.
6. **Step-by-Step Playback**: Use the **Play / Pause**, **Next Step**, and **Speed Slider** to see branches being explored or pruned with exact mathematical explanations.
7. **Switch to Dynamic Programming**: Observe the animated 2D DP Table, cell recurrence highlights, and solution backtrack tracing.
8. **Comparison Suite**: Select multiple algorithms and click **Evaluate & Compare** to see bar charts for Time, Memory, and Explored vs Pruned states.
9. **Scalability Growth Lab**: Run $N=4, 6, 8, 10, 12$ to visually show exponential growth on the line chart.
10. **Download PDF Report**: Click **Download PDF Report** to generate a formatted PDF report suitable for project submission.
