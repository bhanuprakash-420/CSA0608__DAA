@echo off
title NP-Complete Problem Visualizer and Solver
echo ======================================================================
echo    B.Tech DAA Project: NP-Complete Problem Visualizer & Solver
echo    Starting Python Flask Application Server...
echo ======================================================================
echo.

python app.py

pause
