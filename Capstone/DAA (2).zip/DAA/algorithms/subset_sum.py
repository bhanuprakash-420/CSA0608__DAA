"""
Subset Sum Problem Solvers with Step-by-Step Telemetry
Algorithms:
1. Dynamic Programming (Exact Boolean DP Table, O(n * Target))
2. Backtracking (Exact DFS with sum pruning)
3. Branch and Bound (Exact with prefix/suffix bounding)
"""

import copy


def solve_subset_sum(numbers, target, algorithm="dynamic_programming", max_steps=3000):
    if target < 0:
        raise ValueError("Target sum must be non-negative.")
    for num in numbers:
        if num < 0:
            raise ValueError("All numbers in the set must be non-negative integers.")
    if len(numbers) == 0:
        raise ValueError("Number set cannot be empty.")

    items = [{"index": i, "value": int(numbers[i])} for i in range(len(numbers))]

    if algorithm == "dynamic_programming":
        return _solve_subset_sum_dp(items, target, max_steps)
    elif algorithm == "backtracking":
        return _solve_subset_sum_backtracking(items, target, max_steps)
    elif algorithm == "branch_and_bound":
        return _solve_subset_sum_branch_and_bound(items, target, max_steps)
    else:
        raise ValueError(f"Unknown algorithm '{algorithm}' for Subset Sum.")


def _solve_subset_sum_dp(items, target, max_steps):
    n = len(items)
    T = target
    dp = [[False] * (T + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        dp[i][0] = True  # Sum 0 is always achievable with empty subset

    steps = []
    step_id = 0
    states_explored = 0

    steps.append({
        "step_id": step_id,
        "type": "init",
        "action": "init_dp_table",
        "description": f"Initialized Subset Sum DP table ({n + 1} items × {T + 1} sum values). Base case DP[i][0] = True.",
        "dp_table": [row[:] for row in dp],
        "target": target
    })

    for i in range(1, n + 1):
        val = items[i - 1]["value"]
        for s in range(1, T + 1):
            states_explored += 1
            step_id += 1

            prev_state = dp[i - 1][s]
            referenced = [{"row": i - 1, "col": s}]
            
            if s >= val:
                include_state = dp[i - 1][s - val]
                referenced.append({"row": i - 1, "col": s - val})
                dp[i][s] = prev_state or include_state
                formula = f"DP[{i}][{s}] = DP[{i-1}][{s}] ({prev_state}) ∨ DP[{i-1}][{s}-{val}] ({include_state}) = {dp[i][s]}"
            else:
                dp[i][s] = prev_state
                formula = f"Value {val} > current sum {s}. DP[{i}][{s}] = DP[{i-1}][{s}] = {dp[i][s]}"

            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "dp_cell",
                    "action": "fill_subset_cell",
                    "description": f"Item {i} (Val={val}) at Sum={s}: Result is {'TRUE (Achievable)' if dp[i][s] else 'FALSE'}.",
                    "highlight": {"row": i, "col": s, "referenced": referenced},
                    "cell_value": dp[i][s],
                    "formula": formula,
                    "dp_table": [row[:] for row in dp],
                    "current_item": items[i - 1],
                    "current_sum": s
                })

    # Solution reconstruction
    is_solvable = dp[n][T]
    selected_items = []
    
    if is_solvable:
        curr_s = T
        for i in range(n, 0, -1):
            val = items[i - 1]["value"]
            if not dp[i - 1][curr_s] and (curr_s >= val and dp[i - 1][curr_s - val]):
                selected_items.append(items[i - 1])
                curr_s -= val
                step_id += 1
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "backtrack_solution",
                        "action": "subset_element_selected",
                        "description": f"Element {val} (Index {items[i-1]['index']}) SELECTED in subset.",
                        "highlight": {"row": i, "col": curr_s + val, "selected": True},
                        "dp_table": [row[:] for row in dp],
                        "selected_items": [it["value"] for it in selected_items]
                    })
        selected_items.reverse()

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "subset_dp_complete",
        "description": f"Subset Sum DP finished. Target {target} is {'ACHIEVED via ' + str([it['value'] for it in selected_items]) if is_solvable else 'NOT ACHIEVABLE'}." ,
        "selected_subset": [it["value"] for it in selected_items],
        "achieved_sum": sum(it["value"] for it in selected_items)
    })

    return {
        "problem": "Subset Sum",
        "algorithm": "dynamic_programming",
        "algorithm_name": "Dynamic Programming",
        "is_optimal": True,
        "quality_label": "Exact Solution (Guaranteed)",
        "solution": {
            "is_achievable": is_solvable,
            "selected_subset": [it["value"] for it in selected_items],
            "selected_indices": [it["index"] for it in selected_items],
            "target": target,
            "achieved_sum": sum(it["value"] for it in selected_items)
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": 0,
            "total_nodes_generated": (n + 1) * (T + 1),
            "max_tree_depth": n,
            "iterations": (n + 1) * (T + 1)
        },
        "data_structures": {
            "type": "Boolean_DP_Matrix",
            "dimensions": f"{n + 1} × {T + 1}",
            "dp_table": dp,
            "item_labels": [f"Item {i+1} ({it['value']})" for i, it in enumerate(items)],
            "sum_labels": [f"s={s}" for s in range(T + 1)]
        },
        "steps": steps
    }


def _solve_subset_sum_backtracking(items, target, max_steps):
    n = len(items)
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    solution_found = None
    tree_nodes = []

    # Precalculate suffix sums for remaining bound pruning
    suffix_sums = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        suffix_sums[i] = suffix_sums[i + 1] + items[i]["value"]

    def dfs(index, current_sum, current_items, parent_id, branch_label):
        nonlocal step_id, node_counter, states_explored, states_pruned, solution_found

        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "item_index": index,
            "branch": branch_label,
            "current_sum": current_sum,
            "status": "exploring",
            "depth": index,
            "selected_items": list(current_items)
        }
        tree_nodes.append(node_info)

        # Check exact target hit
        if current_sum == target:
            solution_found = list(current_items)
            node_info["status"] = "solution_found"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_solution",
                    "action": "target_achieved",
                    "node_id": node_id,
                    "description": f"EXACT TARGET ACHIEVED at Node {node_id}! Subset = {[items[i]['value'] for i in current_items]} (Sum = {target}).",
                    "current_node": node_info,
                    "selected_items": current_items
                })
            return True

        # Pruning 1: Exceeded target
        if current_sum > target:
            states_pruned += 1
            node_info["status"] = "pruned_exceeded"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_sum_exceeded",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Current sum ({current_sum}) > Target ({target}).",
                    "current_node": node_info,
                    "tree_node": node_info
                })
            return False

        # Pruning 2: Insufficient remaining sum
        if current_sum + suffix_sums[index] < target:
            states_pruned += 1
            node_info["status"] = "pruned_insufficient"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_insufficient_sum",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Max reachable sum ({current_sum + suffix_sums[index]}) < Target ({target}).",
                    "current_node": node_info,
                    "tree_node": node_info
                })
            return False

        if index == n:
            return False

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_explore",
                "action": "explore_branch",
                "node_id": node_id,
                "description": f"Exploring Node {node_id} (Depth {index}): Sum = {current_sum}/{target}, Branch = '{branch_label}'.",
                "current_node": node_info,
                "tree_node": node_info
            })

        # Include branch
        val = items[index]["value"]
        if dfs(index + 1, current_sum + val, current_items + [index], node_id, f"+{val}"):
            return True

        # Exclude branch
        if dfs(index + 1, current_sum, current_items, node_id, f"-{val}"):
            return True

        # Backtrack
        step_id += 1
        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_backtrack",
                "action": "backtrack",
                "description": f"Backtracking from Node {node_id}.",
                "current_node": node_info
            })
        return False

    dfs(0, 0, [], None, "Root")

    selected_objs = [items[i] for i in (solution_found or [])]
    achieved = sum(it["value"] for it in selected_objs)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "backtracking_complete",
        "description": f"Backtracking finished. Solution {'FOUND: ' + str([it['value'] for it in selected_objs]) if solution_found is not None else 'NOT FOUND'}. Explored: {states_explored}, Pruned: {states_pruned}.",
        "selected_subset": [it["value"] for it in selected_objs],
        "achieved_sum": achieved
    })

    return {
        "problem": "Subset Sum",
        "algorithm": "backtracking",
        "algorithm_name": "Backtracking",
        "is_optimal": True,
        "quality_label": "Exact Solution (Guaranteed)",
        "solution": {
            "is_achievable": solution_found is not None,
            "selected_subset": [it["value"] for it in selected_objs],
            "selected_indices": [it["index"] for it in selected_objs],
            "target": target,
            "achieved_sum": achieved
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "State_Space_Tree",
            "tree_nodes": tree_nodes[:500]
        },
        "steps": steps
    }


def _solve_subset_sum_branch_and_bound(items, target, max_steps):
    # Sort items descending for faster bounding & pruning
    sorted_items = sorted(items, key=lambda it: it["value"], reverse=True)
    n = len(sorted_items)
    
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    solution_found = None
    tree_nodes = []

    suffix_sums = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        suffix_sums[i] = suffix_sums[i + 1] + sorted_items[i]["value"]

    def bnb_dfs(index, current_sum, current_indices, parent_id, branch_label):
        nonlocal step_id, node_counter, states_explored, states_pruned, solution_found

        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        upper_bound = current_sum + suffix_sums[index]

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "item_index": index,
            "branch": branch_label,
            "current_sum": current_sum,
            "upper_bound": upper_bound,
            "status": "exploring",
            "depth": index,
            "selected_items": list(current_indices)
        }
        tree_nodes.append(node_info)

        if current_sum == target:
            solution_found = list(current_indices)
            node_info["status"] = "solution_found"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_solution",
                    "action": "target_achieved",
                    "node_id": node_id,
                    "description": f"EXACT TARGET REACHED at B&B Node {node_id}: Subset = {[sorted_items[i]['value'] for i in current_indices]} (Sum = {target}).",
                    "current_node": node_info
                })
            return True

        # Upper bound pruning: if max achievable sum is less than target
        if upper_bound < target:
            states_pruned += 1
            node_info["status"] = "pruned_bound"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_upper_bound",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Upper Bound ({upper_bound}) < Target ({target}). Branch cannot reach sum.",
                    "current_node": node_info,
                    "tree_node": node_info
                })
            return False

        # Lower bound / sum exceeded pruning
        if current_sum > target:
            states_pruned += 1
            node_info["status"] = "pruned_exceeded"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_sum_exceeded",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Current sum {current_sum} exceeds target {target}.",
                    "current_node": node_info,
                    "tree_node": node_info
                })
            return False

        if index == n:
            return False

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_explore",
                "action": "explore_bnb_branch",
                "node_id": node_id,
                "description": f"Exploring B&B Node {node_id}: Sum = {current_sum}, Upper Bound = {upper_bound}, Target = {target}.",
                "current_node": node_info,
                "tree_node": node_info
            })

        val = sorted_items[index]["value"]
        if bnb_dfs(index + 1, current_sum + val, current_indices + [index], node_id, f"+{val}"):
            return True

        if bnb_dfs(index + 1, current_sum, current_indices, node_id, f"-{val}"):
            return True

        return False

    bnb_dfs(0, 0, [], None, "Root")

    selected_objs = [sorted_items[i] for i in (solution_found or [])]
    achieved = sum(it["value"] for it in selected_objs)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "bnb_complete",
        "description": f"Branch and Bound complete. Solvable: {solution_found is not None}. Explored: {states_explored}, Pruned: {states_pruned}.",
        "selected_subset": [it["value"] for it in selected_objs],
        "achieved_sum": achieved
    })

    return {
        "problem": "Subset Sum",
        "algorithm": "branch_and_bound",
        "algorithm_name": "Branch and Bound",
        "is_optimal": True,
        "quality_label": "Exact Solution (Guaranteed)",
        "solution": {
            "is_achievable": solution_found is not None,
            "selected_subset": [it["value"] for it in selected_objs],
            "selected_indices": [it["index"] for it in selected_objs],
            "target": target,
            "achieved_sum": achieved
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Branch_and_Bound_Tree",
            "tree_nodes": tree_nodes[:500]
        },
        "steps": steps
    }
