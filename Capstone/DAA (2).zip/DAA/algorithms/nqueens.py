"""
N-Queens Problem Solvers with Step-by-Step Telemetry
Algorithms:
1. Backtracking (Exact DFS with diagonal and column conflict checks)
2. Branch and Bound (Exact with Forward Checking & Bitmask Bounding)
"""

import copy


def solve_nqueens(n, algorithm="backtracking", find_all=False, max_steps=3000):
    if n < 1:
        raise ValueError("N must be an integer >= 1.")
    if n in (2, 3):
        # N=2, 3 have no solutions, but we still run and demonstrate search
        pass

    if algorithm == "backtracking":
        return _solve_nqueens_backtracking(n, find_all, max_steps)
    elif algorithm == "branch_and_bound":
        return _solve_nqueens_branch_and_bound(n, find_all, max_steps)
    else:
        raise ValueError(f"Unknown algorithm '{algorithm}' for N-Queens.")


def _is_safe(queens, row, col):
    """Check if placing queen at (row, col) is attacked by existing queens"""
    for r, c in enumerate(queens):
        if c == col:
            return False, {"type": "column", "attacker": [r, c], "target": [row, col]}
        if abs(r - row) == abs(c - col):
            return False, {"type": "diagonal", "attacker": [r, c], "target": [row, col]}
    return True, None


def _solve_nqueens_backtracking(n, find_all, max_steps):
    steps = []
    step_id = 0
    states_explored = 0
    states_pruned = 0
    solutions = []
    tree_nodes = []
    node_counter = 0

    steps.append({
        "step_id": step_id,
        "type": "nqueens_init",
        "action": "init_board",
        "description": f"Initialized {n}x{n} chessboard for Backtracking search.",
        "board_size": n,
        "current_board": [-1] * n,
        "current_row": 0
    })

    def backtrack(row, current_queens, parent_id):
        nonlocal step_id, states_explored, states_pruned, node_counter

        if row == n:
            solutions.append(list(current_queens))
            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_solution",
                    "action": "solution_found",
                    "description": f"VALID SOLUTION #{len(solutions)} FOUND! All {n} queens placed peacefully without conflicts.",
                    "board_size": n,
                    "current_board": list(current_queens),
                    "current_row": row,
                    "solution_count": len(solutions)
                })
            return not find_all  # return True to stop after 1st solution if find_all is False

        for col in range(n):
            node_id = node_counter
            node_counter += 1
            states_explored += 1
            step_id += 1

            safe, conflict_info = _is_safe(current_queens, row, col)

            node_info = {
                "id": node_id,
                "parent_id": parent_id,
                "row": row,
                "col": col,
                "status": "safe" if safe else "conflict"
            }
            tree_nodes.append(node_info)

            if not safe:
                states_pruned += 1
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "nqueens_conflict",
                        "action": "conflict_detected",
                        "description": f"CONFLICT at ({row}, {col}): Attacked along {conflict_info['type']} by Queen at {conflict_info['attacker']}.",
                        "board_size": n,
                        "current_board": list(current_queens) + [col],
                        "current_row": row,
                        "conflict": conflict_info,
                        "candidate": [row, col],
                        "tree_node": node_info
                    })
                continue

            # Place queen
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_place",
                    "action": "place_queen",
                    "description": f"Placed Queen at Row {row}, Col {col} (Safe position). Proceeding to Row {row + 1}.",
                    "board_size": n,
                    "current_board": list(current_queens) + [col],
                    "current_row": row + 1,
                    "placed_queen": [row, col],
                    "tree_node": node_info
                })

            if backtrack(row + 1, current_queens + [col], node_id):
                return True

            # Backtrack / remove queen
            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_backtrack",
                    "action": "remove_queen",
                    "description": f"Backtracking: Removed Queen from Row {row}, Col {col}.",
                    "board_size": n,
                    "current_board": list(current_queens),
                    "current_row": row,
                    "removed_queen": [row, col]
                })

        return False

    backtrack(0, [], None)

    best_sol = solutions[0] if solutions else None

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "search_complete",
        "description": f"N-Queens Backtracking complete. Solutions Found = {len(solutions)}, Explored = {states_explored}, Pruned = {states_pruned}.",
        "board_size": n,
        "solution": best_sol,
        "total_solutions": len(solutions)
    })

    return {
        "problem": "N-Queens",
        "algorithm": "backtracking",
        "algorithm_name": "Backtracking",
        "is_optimal": True,
        "quality_label": "Exact Solution (Guaranteed)",
        "solution": {
            "board_size": n,
            "has_solution": len(solutions) > 0,
            "solution_board": best_sol,
            "queen_positions": [[r, best_sol[r]] for r in range(n)] if best_sol else [],
            "total_solutions_found": len(solutions)
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Chessboard_Matrix",
            "board_size": n,
            "tree_nodes": tree_nodes[:400]
        },
        "steps": steps
    }


def _solve_nqueens_branch_and_bound(n, find_all, max_steps):
    steps = []
    step_id = 0
    states_explored = 0
    states_pruned = 0
    solutions = []
    tree_nodes = []
    node_counter = 0

    cols_used = [False] * n
    slash_diag = [False] * (2 * n - 1)   # row + col
    bslash_diag = [False] * (2 * n - 1)  # row - col + n - 1

    steps.append({
        "step_id": step_id,
        "type": "nqueens_init",
        "action": "init_bnb_board",
        "description": f"Branch & Bound initialized for N={n} with bitmask domain lookahead (Forward Checking).",
        "board_size": n,
        "current_board": [-1] * n,
        "current_row": 0
    })

    def count_valid_positions_in_future_rows(start_row, curr_queens):
        """Forward checking: ensure every future row has >= 1 valid safe square"""
        for r in range(start_row, n):
            has_valid = False
            for c in range(n):
                if not cols_used[c] and not slash_diag[r + c] and not bslash_diag[r - c + n - 1]:
                    has_valid = True
                    break
            if not has_valid:
                return False, r  # Row r has no valid squares left!
        return True, -1

    def bnb_search(row, current_queens, parent_id):
        nonlocal step_id, states_explored, states_pruned, node_counter

        if row == n:
            solutions.append(list(current_queens))
            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_solution",
                    "action": "solution_found",
                    "description": f"VALID B&B SOLUTION #{len(solutions)} FOUND! Placed {n} queens.",
                    "board_size": n,
                    "current_board": list(current_queens),
                    "current_row": row,
                    "solution_count": len(solutions)
                })
            return not find_all

        for col in range(n):
            node_id = node_counter
            node_counter += 1
            states_explored += 1
            step_id += 1

            # B&B Bitmask safety check
            if cols_used[col] or slash_diag[row + col] or bslash_diag[row - col + n - 1]:
                states_pruned += 1
                reason = "Column conflict" if cols_used[col] else "Diagonal conflict"
                node_info = {"id": node_id, "parent_id": parent_id, "row": row, "col": col, "status": "pruned_conflict"}
                tree_nodes.append(node_info)
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "nqueens_conflict",
                        "action": "prune_conflict",
                        "description": f"PRUNED at ({row}, {col}): {reason}.",
                        "board_size": n,
                        "current_board": list(current_queens) + [col],
                        "current_row": row,
                        "candidate": [row, col],
                        "tree_node": node_info
                    })
                continue

            # Tentatively place queen
            cols_used[col] = True
            slash_diag[row + col] = True
            bslash_diag[row - col + n - 1] = True

            node_info = {"id": node_id, "parent_id": parent_id, "row": row, "col": col, "status": "placed"}
            tree_nodes.append(node_info)

            # Forward Checking Bounding: verify future rows are not starved
            domain_ok, starved_row = count_valid_positions_in_future_rows(row + 1, current_queens + [col])

            if not domain_ok:
                # PRUNE entire subtree because a future row has 0 valid squares left
                states_pruned += 1
                node_info["status"] = "pruned_forward_check"
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "nqueens_prune",
                        "action": "prune_forward_check",
                        "description": f"FORWARD CHECKING PRUNED: Placing Queen at ({row}, {col}) starves Row {starved_row} of all valid moves!",
                        "board_size": n,
                        "current_board": list(current_queens) + [col],
                        "current_row": row,
                        "starved_row": starved_row,
                        "tree_node": node_info
                    })
                # Revert placement
                cols_used[col] = False
                slash_diag[row + col] = False
                bslash_diag[row - col + n - 1] = False
                continue

            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_place",
                    "action": "place_queen_bnb",
                    "description": f"Placed Queen at ({row}, {col}). Forward checking verified all future rows have valid placements.",
                    "board_size": n,
                    "current_board": list(current_queens) + [col],
                    "current_row": row + 1,
                    "placed_queen": [row, col],
                    "tree_node": node_info
                })

            if bnb_search(row + 1, current_queens + [col], node_id):
                return True

            # Backtrack
            cols_used[col] = False
            slash_diag[row + col] = False
            bslash_diag[row - col + n - 1] = False

            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "nqueens_backtrack",
                    "action": "remove_queen_bnb",
                    "description": f"Backtracked: Removed Queen at ({row}, {col}).",
                    "board_size": n,
                    "current_board": list(current_queens),
                    "current_row": row
                })

        return False

    bnb_search(0, [], None)

    best_sol = solutions[0] if solutions else None

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "bnb_search_complete",
        "description": f"Branch & Bound search complete. Solutions = {len(solutions)}, Explored = {states_explored}, Pruned = {states_pruned}.",
        "board_size": n,
        "solution": best_sol,
        "total_solutions": len(solutions)
    })

    return {
        "problem": "N-Queens",
        "algorithm": "branch_and_bound",
        "algorithm_name": "Branch and Bound (Forward Checking)",
        "is_optimal": True,
        "quality_label": "Exact Solution (Guaranteed)",
        "solution": {
            "board_size": n,
            "has_solution": len(solutions) > 0,
            "solution_board": best_sol,
            "queen_positions": [[r, best_sol[r]] for r in range(n)] if best_sol else [],
            "total_solutions_found": len(solutions)
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Chessboard_and_Bitmasks",
            "board_size": n,
            "tree_nodes": tree_nodes[:400]
        },
        "steps": steps
    }
