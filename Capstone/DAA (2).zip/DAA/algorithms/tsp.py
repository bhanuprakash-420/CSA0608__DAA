"""
Travelling Salesman Problem (TSP) Solvers with Step-by-Step Telemetry
Algorithms:
1. Backtracking (Exact DFS with branch pruning)
2. Branch and Bound (Exact with Lower Bounding)
3. Greedy Heuristic (Nearest Neighbor, O(n^2))
4. 2-Opt Approximation Algorithm (Local Search 2-Opt)
"""

import math
import copy


def solve_tsp(matrix, coordinates=None, algorithm="branch_and_bound", max_steps=3000):
    n = len(matrix)
    if n < 3:
        raise ValueError("TSP requires at least 3 cities.")
    for row in matrix:
        if len(row) != n:
            raise ValueError("Distance matrix must be square (N x N).")

    # Generate visual 2D coordinates if not provided (circular layout)
    if not coordinates or len(coordinates) != n:
        coordinates = []
        center_x, center_y, radius = 250, 250, 180
        for i in range(n):
            angle = (2 * math.pi * i) / n - (math.pi / 2)
            coordinates.append({
                "x": round(center_x + radius * math.cos(angle)),
                "y": round(center_y + radius * math.sin(angle)),
                "label": f"City {chr(65 + i) if i < 26 else i}"
            })
    else:
        coordinates = [{"x": c[0] if isinstance(c, (list, tuple)) else c.get("x", 0),
                        "y": c[1] if isinstance(c, (list, tuple)) else c.get("y", 0),
                        "label": f"City {chr(65 + i) if i < 26 else i}"} for i, c in enumerate(coordinates)]

    city_names = [c["label"] for c in coordinates]

    if algorithm == "backtracking":
        return _solve_tsp_backtracking(matrix, coordinates, city_names, max_steps)
    elif algorithm == "branch_and_bound":
        return _solve_tsp_branch_and_bound(matrix, coordinates, city_names, max_steps)
    elif algorithm == "greedy":
        return _solve_tsp_greedy(matrix, coordinates, city_names, max_steps)
    elif algorithm == "two_opt" or algorithm == "approximation":
        return _solve_tsp_two_opt(matrix, coordinates, city_names, max_steps)
    else:
        raise ValueError(f"Unknown algorithm '{algorithm}' for TSP.")


def _calculate_tour_distance(tour, matrix):
    dist = 0
    for i in range(len(tour)):
        u = tour[i]
        v = tour[(i + 1) % len(tour)]
        dist += matrix[u][v]
    return dist


def _solve_tsp_backtracking(matrix, coordinates, city_names, max_steps):
    n = len(matrix)
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    best_cost = float("inf")
    best_tour = []
    tree_nodes = []

    steps.append({
        "step_id": step_id,
        "type": "tsp_init",
        "action": "start_search",
        "description": f"Starting TSP Backtracking with {n} cities. Origin: {city_names[0]}.",
        "current_tour": [0],
        "current_cost": 0,
        "best_cost": None,
        "active_edge": None
    })

    def dfs(curr_city, visited_mask, current_path, current_cost, parent_id):
        nonlocal step_id, node_counter, states_explored, states_pruned, best_cost, best_tour

        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "city": curr_city,
            "path": list(current_path),
            "cost": current_cost,
            "status": "exploring"
        }
        tree_nodes.append(node_info)

        # Pruning check: if current path cost already exceeds or equals incumbent best cost
        if current_cost >= best_cost:
            states_pruned += 1
            node_info["status"] = "pruned_cost"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tsp_prune",
                    "action": "prune_cost_exceeded",
                    "node_id": node_id,
                    "description": f"PRUNED at {city_names[curr_city]}: Partial cost ({current_cost}) >= Best known cost ({best_cost}).",
                    "current_tour": list(current_path),
                    "current_cost": current_cost,
                    "best_cost": best_cost,
                    "best_tour": list(best_tour),
                    "tree_node": node_info
                })
            return

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tsp_step",
                "action": "visit_city",
                "node_id": node_id,
                "description": f"Visited {city_names[curr_city]}. Path: {' -> '.join(city_names[c] for c in current_path)} (Cost: {current_cost}).",
                "current_tour": list(current_path),
                "current_cost": current_cost,
                "best_cost": best_cost if best_cost != float("inf") else None,
                "best_tour": list(best_tour),
                "tree_node": node_info
            })

        # If all cities visited, close the tour back to 0
        if len(current_path) == n:
            return_edge_cost = matrix[curr_city][0]
            total_tour_cost = current_cost + return_edge_cost
            full_tour = current_path + [0]
            step_id += 1

            if total_tour_cost < best_cost:
                best_cost = total_tour_cost
                best_tour = full_tour
                node_info["status"] = "new_best"
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "tsp_update_best",
                        "action": "new_best_tour",
                        "description": f"NEW SHORTEST TOUR found: {' -> '.join(city_names[c] for c in full_tour)} with Total Cost = {best_cost}.",
                        "current_tour": full_tour,
                        "current_cost": total_tour_cost,
                        "best_cost": best_cost,
                        "best_tour": list(best_tour),
                        "tree_node": node_info
                    })
            else:
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "tsp_complete_tour",
                        "action": "tour_evaluated",
                        "description": f"Complete Tour: {' -> '.join(city_names[c] for c in full_tour)} (Cost: {total_tour_cost}) is not better than best ({best_cost}).",
                        "current_tour": full_tour,
                        "current_cost": total_tour_cost,
                        "best_cost": best_cost,
                        "best_tour": list(best_tour)
                    })
            return

        # Branch to all unvisited neighbors
        for next_city in range(n):
            if not (visited_mask & (1 << next_city)):
                edge_wt = matrix[curr_city][next_city]
                dfs(next_city, visited_mask | (1 << next_city), current_path + [next_city], current_cost + edge_wt, node_id)

        # Backtrack step
        step_id += 1
        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tsp_backtrack",
                "action": "backtrack",
                "description": f"Backtracking from {city_names[curr_city]}.",
                "current_tour": list(current_path),
                "current_cost": current_cost,
                "best_cost": best_cost,
                "best_tour": list(best_tour)
            })

    dfs(0, 1, [0], 0, None)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "tsp_solved",
        "description": f"Optimal Tour found: {' -> '.join(city_names[c] for c in best_tour)} with Minimum Distance = {best_cost}.",
        "best_tour": best_tour,
        "best_cost": best_cost
    })

    return {
        "problem": "Travelling Salesman Problem",
        "algorithm": "backtracking",
        "algorithm_name": "Backtracking",
        "is_optimal": True,
        "quality_label": "Optimal Solution (Guaranteed)",
        "solution": {
            "tour": best_tour,
            "tour_names": [city_names[c] for c in best_tour],
            "total_distance": best_cost,
            "num_cities": n
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Adjacency_Matrix_and_Graph",
            "matrix": matrix,
            "coordinates": coordinates,
            "tree_nodes": tree_nodes[:400]
        },
        "steps": steps
    }


def _solve_tsp_branch_and_bound(matrix, coordinates, city_names, max_steps):
    n = len(matrix)
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    best_cost = float("inf")
    best_tour = []
    tree_nodes = []

    # Precalculate minimum outgoing edge for each vertex to construct lower bounds
    min_outgoing = []
    for i in range(n):
        row_min = min(matrix[i][j] for j in range(n) if i != j)
        min_outgoing.append(row_min)

    def calculate_lower_bound(current_path, current_cost, visited_mask):
        """Calculates 1-tree / minimum outgoing edges lower bound"""
        bound = current_cost
        curr_city = current_path[-1]
        
        # Add min outgoing edges for all unvisited cities
        for i in range(n):
            if not (visited_mask & (1 << i)):
                bound += min_outgoing[i]
        
        # Return edge bound to origin (city 0)
        if len(current_path) < n:
            bound += min_outgoing[curr_city]
        else:
            bound += matrix[curr_city][0]
            
        return bound

    initial_lb = sum(min_outgoing)

    steps.append({
        "step_id": step_id,
        "type": "tsp_init",
        "action": "bnb_init",
        "description": f"Branch & Bound initialized. Root Lower Bound = {initial_lb}.",
        "current_tour": [0],
        "current_cost": 0,
        "lower_bound": initial_lb,
        "best_cost": None
    })

    def bnb_dfs(curr_city, visited_mask, current_path, current_cost, parent_id):
        nonlocal step_id, node_counter, states_explored, states_pruned, best_cost, best_tour

        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        lb = calculate_lower_bound(current_path, current_cost, visited_mask)

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "city": curr_city,
            "path": list(current_path),
            "cost": current_cost,
            "lower_bound": lb,
            "status": "exploring"
        }
        tree_nodes.append(node_info)

        # Prune if Lower Bound >= Best known cost
        if lb >= best_cost:
            states_pruned += 1
            node_info["status"] = "pruned_bound"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tsp_prune",
                    "action": "prune_lower_bound",
                    "node_id": node_id,
                    "description": f"PRUNED at {city_names[curr_city]}: Lower Bound ({lb}) >= Best Cost ({best_cost}). Subtree cannot improve best tour.",
                    "current_tour": list(current_path),
                    "current_cost": current_cost,
                    "lower_bound": lb,
                    "best_cost": best_cost,
                    "best_tour": list(best_tour),
                    "tree_node": node_info
                })
            return

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tsp_step",
                "action": "explore_bnb_node",
                "node_id": node_id,
                "description": f"Exploring Node {node_id} ({city_names[curr_city]}): Cost={current_cost}, Lower Bound={lb}, Best={best_cost if best_cost != float('inf') else 'inf'}.",
                "current_tour": list(current_path),
                "current_cost": current_cost,
                "lower_bound": lb,
                "best_cost": best_cost if best_cost != float("inf") else None,
                "best_tour": list(best_tour),
                "tree_node": node_info
            })

        if len(current_path) == n:
            total_tour_cost = current_cost + matrix[curr_city][0]
            full_tour = current_path + [0]
            step_id += 1

            if total_tour_cost < best_cost:
                best_cost = total_tour_cost
                best_tour = full_tour
                node_info["status"] = "new_best"
                if len(steps) < max_steps:
                    steps.append({
                        "step_id": step_id,
                        "type": "tsp_update_best",
                        "action": "new_best_tour",
                        "description": f"NEW BEST TOUR via B&B: {' -> '.join(city_names[c] for c in full_tour)} (Cost = {best_cost}).",
                        "current_tour": full_tour,
                        "current_cost": total_tour_cost,
                        "best_cost": best_cost,
                        "best_tour": list(best_tour),
                        "tree_node": node_info
                    })
            return

        # Sort candidate child branches by edge cost for best-first exploration
        candidates = []
        for next_city in range(n):
            if not (visited_mask & (1 << next_city)):
                candidates.append((matrix[curr_city][next_city], next_city))
        candidates.sort(key=lambda x: x[0])

        for edge_wt, next_city in candidates:
            bnb_dfs(next_city, visited_mask | (1 << next_city), current_path + [next_city], current_cost + edge_wt, node_id)

    bnb_dfs(0, 1, [0], 0, None)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "tsp_bnb_complete",
        "description": f"Branch & Bound completed. Optimal Tour: {' -> '.join(city_names[c] for c in best_tour)} (Distance: {best_cost}). Explored: {states_explored}, Pruned: {states_pruned}.",
        "best_tour": best_tour,
        "best_cost": best_cost
    })

    return {
        "problem": "Travelling Salesman Problem",
        "algorithm": "branch_and_bound",
        "algorithm_name": "Branch and Bound",
        "is_optimal": True,
        "quality_label": "Optimal Solution (Guaranteed)",
        "solution": {
            "tour": best_tour,
            "tour_names": [city_names[c] for c in best_tour],
            "total_distance": best_cost,
            "num_cities": n
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Adjacency_Matrix_and_Graph",
            "matrix": matrix,
            "coordinates": coordinates,
            "tree_nodes": tree_nodes[:400]
        },
        "steps": steps
    }


def _solve_tsp_greedy(matrix, coordinates, city_names, max_steps):
    n = len(matrix)
    steps = []
    step_id = 0
    visited = [False] * n
    
    current_city = 0
    visited[0] = True
    tour = [0]
    total_cost = 0

    steps.append({
        "step_id": step_id,
        "type": "greedy_init",
        "action": "start_greedy",
        "description": f"Nearest Neighbor heuristic started at origin {city_names[0]}.",
        "current_tour": list(tour),
        "current_cost": 0
    })

    for step_idx in range(n - 1):
        step_id += 1
        nearest_city = None
        min_dist = float("inf")
        candidate_evals = []

        for candidate in range(n):
            if not visited[candidate]:
                dist = matrix[current_city][candidate]
                candidate_evals.append({"city": candidate, "name": city_names[candidate], "distance": dist})
                if dist < min_dist:
                    min_dist = dist
                    nearest_city = candidate

        visited[nearest_city] = True
        tour.append(nearest_city)
        total_cost += min_dist

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "greedy_step",
                "action": "choose_nearest_neighbor",
                "description": f"From {city_names[current_city]}, closest unvisited is {city_names[nearest_city]} (Distance: {min_dist}). Added to tour.",
                "current_tour": list(tour),
                "current_cost": total_cost,
                "candidates": candidate_evals,
                "chosen_city": nearest_city
            })
        current_city = nearest_city

    # Connect back to origin
    return_dist = matrix[current_city][0]
    total_cost += return_dist
    tour.append(0)
    step_id += 1

    steps.append({
        "step_id": step_id,
        "type": "complete",
        "action": "greedy_complete",
        "description": f"Nearest Neighbor complete. Return to origin {city_names[0]} (+{return_dist}). Total Distance = {total_cost}.",
        "current_tour": tour,
        "current_cost": total_cost,
        "best_tour": tour,
        "best_cost": total_cost
    })

    return {
        "problem": "Travelling Salesman Problem",
        "algorithm": "greedy",
        "algorithm_name": "Greedy Heuristic (Nearest Neighbor)",
        "is_optimal": False,
        "quality_label": "Approximate Solution (Heuristic)",
        "solution": {
            "tour": tour,
            "tour_names": [city_names[c] for c in tour],
            "total_distance": total_cost,
            "num_cities": n
        },
        "statistics": {
            "states_explored": n,
            "states_pruned": 0,
            "total_nodes_generated": n,
            "max_tree_depth": n,
            "iterations": n
        },
        "data_structures": {
            "type": "Adjacency_Matrix_and_Graph",
            "matrix": matrix,
            "coordinates": coordinates
        },
        "steps": steps
    }


def _solve_tsp_two_opt(matrix, coordinates, city_names, max_steps):
    # Initial tour via greedy nearest neighbor
    greedy_res = _solve_tsp_greedy(matrix, coordinates, city_names, max_steps=10)
    current_tour = greedy_res["solution"]["tour"][:-1]  # exclude trailing 0 for internal representation
    n = len(current_tour)
    
    current_distance = _calculate_tour_distance(current_tour, matrix)
    steps = []
    step_id = 0
    improved = True
    iterations = 0
    swaps_performed = 0

    steps.append({
        "step_id": step_id,
        "type": "two_opt_init",
        "action": "init_tour",
        "description": f"2-Opt Approximation started with initial greedy tour (Distance: {current_distance}).",
        "current_tour": current_tour + [current_tour[0]],
        "current_cost": current_distance
    })

    while improved and iterations < 100:
        improved = False
        iterations += 1

        for i in range(1, n - 1):
            for j in range(i + 1, n):
                step_id += 1
                # 2-opt swap cost difference
                # current edges: (i-1, i) and (j, (j+1)%n)
                # new edges: (i-1, j) and (i, (j+1)%n)
                u1, v1 = current_tour[i - 1], current_tour[i]
                u2, v2 = current_tour[j], current_tour[(j + 1) % n]

                old_edges_cost = matrix[u1][v1] + matrix[u2][v2]
                new_edges_cost = matrix[u1][u2] + matrix[v1][v2]

                delta = new_edges_cost - old_edges_cost

                if delta < -1e-6:
                    # Reverse segment i..j
                    current_tour[i:j + 1] = reversed(current_tour[i:j + 1])
                    current_distance += delta
                    swaps_performed += 1
                    improved = True

                    if len(steps) < max_steps:
                        steps.append({
                            "step_id": step_id,
                            "type": "two_opt_swap",
                            "action": "perform_2opt_swap",
                            "description": f"2-Opt Swap between ({city_names[u1]}-{city_names[v1]}) and ({city_names[u2]}-{city_names[v2]}). Distance improved by {abs(delta)} to {round(current_distance, 2)}.",
                            "current_tour": current_tour + [current_tour[0]],
                            "current_cost": round(current_distance, 2),
                            "swap_indices": [i, j]
                        })
                    break
            if improved:
                break

    final_tour = current_tour + [current_tour[0]]
    final_cost = _calculate_tour_distance(current_tour, matrix)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "two_opt_complete",
        "description": f"2-Opt Local Search completed. Swaps: {swaps_performed}, Final Distance = {round(final_cost, 2)}.",
        "best_tour": final_tour,
        "best_cost": round(final_cost, 2)
    })

    return {
        "problem": "Travelling Salesman Problem",
        "algorithm": "approximation",
        "algorithm_name": "2-Opt Approximation",
        "is_optimal": False,
        "quality_label": "Approximate Solution (2-Opt Local Search)",
        "solution": {
            "tour": final_tour,
            "tour_names": [city_names[c] for c in final_tour],
            "total_distance": round(final_cost, 2),
            "num_cities": n
        },
        "statistics": {
            "states_explored": iterations * n,
            "states_pruned": 0,
            "total_nodes_generated": swaps_performed,
            "max_tree_depth": n,
            "iterations": iterations
        },
        "data_structures": {
            "type": "Adjacency_Matrix_and_Graph",
            "matrix": matrix,
            "coordinates": coordinates
        },
        "steps": steps
    }
