"""
Algorithms module for NP-Complete Problem Visualizer and Solver.
Contains exact, verified solvers with step-by-step telemetry for:
- 0/1 Knapsack
- Travelling Salesman Problem (TSP)
- Subset Sum
- N-Queens
"""

from .knapsack import solve_knapsack
from .tsp import solve_tsp
from .subset_sum import solve_subset_sum
from .nqueens import solve_nqueens

__all__ = ["solve_knapsack", "solve_tsp", "solve_subset_sum", "solve_nqueens"]
