"""
0/1 Knapsack Problem Solvers with Step-by-Step Telemetry
Algorithms:
1. Dynamic Programming (Exact, O(nW))
2. Backtracking (Exact, O(2^n))
3. Branch and Bound (Exact, Best-First with Fractional Knapsack Upper Bound)
4. Greedy Heuristic (Approximate, O(n log n))
"""

import copy


def solve_knapsack(weights, values, capacity, algorithm="dynamic_programming", max_steps=3000):
    n = len(weights)
    if n != len(values):
        raise ValueError("Weights and values arrays must have equal length.")
    if capacity < 0:
        raise ValueError("Capacity cannot be negative.")
    for w in weights:
        if w < 0:
            raise ValueError("Item weights must be non-negative integers.")
    for v in values:
        if v < 0:
            raise ValueError("Item values must be non-negative integers.")

    items = [{"id": i, "weight": int(weights[i]), "value": int(values[i]), "ratio": round(values[i] / weights[i], 3) if weights[i] > 0 else 999999} for i in range(n)]

    if algorithm == "dynamic_programming":
        return _solve_knapsack_dp(items, capacity, max_steps)
    elif algorithm == "backtracking":
        return _solve_knapsack_backtracking(items, capacity, max_steps)
    elif algorithm == "branch_and_bound":
        return _solve_knapsack_branch_and_bound(items, capacity, max_steps)
    elif algorithm == "greedy":
        return _solve_knapsack_greedy(items, capacity, max_steps)
    else:
        raise ValueError(f"Unknown algorithm '{algorithm}' for 0/1 Knapsack.")


def _solve_knapsack_dp(items, capacity, max_steps):
    n = len(items)
    W = capacity
    dp = [[0] * (W + 1) for _ in range(n + 1)]
    steps = []
    step_id = 0
    states_explored = 0

    steps.append({
        "step_id": step_id,
        "type": "init",
        "action": "initialize_table",
        "description": f"Initialized DP table of dimensions ({n + 1} items × {W + 1} capacities) with zeros.",
        "highlight": {"row": 0, "col": 0},
        "dp_table": [row[:] for row in dp],
        "current_item": None,
        "current_weight": 0,
        "current_value": 0,
        "formula": "DP[i][w] = 0 for base cases"
    })

    # Fill DP table
    for i in range(1, n + 1):
        item = items[i - 1]
        w_i = item["weight"]
        v_i = item["value"]
        
        for w in range(W + 1):
            states_explored += 1
            step_id += 1
            
            if w_i <= w:
                val_exclude = dp[i - 1][w]
                val_include = dp[i - 1][w - w_i] + v_i
                if val_include > val_exclude:
                    dp[i][w] = val_include
                    choice = "INCLUDE"
                    formula = f"DP[{i}][{w}] = max(DP[{i-1}][{w}] ({val_exclude}), DP[{i-1}][{w}-{w_i}] + {v_i} ({val_include})) = {val_include} (Included item {i})"
                    referenced = [{"row": i - 1, "col": w}, {"row": i - 1, "col": w - w_i}]
                else:
                    dp[i][w] = val_exclude
                    choice = "EXCLUDE"
                    formula = f"DP[{i}][{w}] = max(DP[{i-1}][{w}] ({val_exclude}), DP[{i-1}][{w}-{w_i}] + {v_i} ({val_include})) = {val_exclude} (Excluded item {i})"
                    referenced = [{"row": i - 1, "col": w}]
            else:
                dp[i][w] = dp[i - 1][w]
                choice = "CANNOT_INCLUDE"
                formula = f"Item {i} weight ({w_i}) > capacity ({w}). DP[{i}][{w}] = DP[{i-1}][{w}] = {dp[i][w]}"
                referenced = [{"row": i - 1, "col": w}]

            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "dp_cell",
                    "action": f"fill_cell_{choice.lower()}",
                    "description": f"Evaluating Item {i} (W={w_i}, V={v_i}) at sub-capacity w={w}. {choice}: cell value = {dp[i][w]}.",
                    "highlight": {"row": i, "col": w, "referenced": referenced},
                    "cell_value": dp[i][w],
                    "formula": formula,
                    "dp_table": [row[:] for row in dp],
                    "current_item": item,
                    "current_weight": w,
                    "current_value": dp[i][w]
                })

    # Backtracking to find selected items
    selected_items = []
    curr_w = W
    
    for i in range(n, 0, -1):
        item = items[i - 1]
        if dp[i][curr_w] != dp[i - 1][curr_w]:
            selected_items.append(item)
            curr_w -= item["weight"]
            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "backtrack_solution",
                    "action": "item_selected",
                    "description": f"DP[{i}][{curr_w + item['weight']}] != DP[{i-1}][{curr_w + item['weight']}]: Item {i} (W={item['weight']}, V={item['value']}) was SELECTED.",
                    "highlight": {"row": i, "col": curr_w + item["weight"], "selected": True},
                    "dp_table": [row[:] for row in dp],
                    "selected_items": [it["id"] for it in selected_items],
                    "formula": f"Item {i} included -> sub-capacity decreases to {curr_w}"
                })
        else:
            step_id += 1
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "backtrack_solution",
                    "action": "item_skipped",
                    "description": f"DP[{i}][{curr_w}] == DP[{i-1}][{curr_w}]: Item {i} was NOT selected.",
                    "highlight": {"row": i, "col": curr_w, "selected": False},
                    "dp_table": [row[:] for row in dp],
                    "selected_items": [it["id"] for it in selected_items],
                    "formula": f"Item {i} excluded -> sub-capacity remains {curr_w}"
                })

    selected_items.reverse()
    total_val = dp[n][W]
    total_wt = sum(it["weight"] for it in selected_items)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "optimal_solution_found",
        "description": f"Optimal DP solution found with Maximum Value = {total_val}, Total Weight = {total_wt}/{capacity}.",
        "highlight": {"optimal_items": [it["id"] for it in selected_items]},
        "dp_table": [row[:] for row in dp],
        "selected_items": [it["id"] for it in selected_items],
        "formula": f"Optimal Solution Value: {total_val}"
    })

    return {
        "problem": "0/1 Knapsack",
        "algorithm": "dynamic_programming",
        "algorithm_name": "Dynamic Programming",
        "is_optimal": True,
        "quality_label": "Optimal Solution (Guaranteed)",
        "solution": {
            "selected_indices": [it["id"] for it in selected_items],
            "selected_items": selected_items,
            "total_value": total_val,
            "total_weight": total_wt,
            "capacity": capacity
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": 0,
            "total_nodes_generated": (n + 1) * (W + 1),
            "max_tree_depth": n,
            "iterations": (n + 1) * (W + 1)
        },
        "data_structures": {
            "type": "2D_Matrix",
            "dimensions": f"{n + 1} × {W + 1}",
            "dp_table": dp,
            "item_labels": [f"Item {i+1} (W={it['weight']}, V={it['value']})" for i, it in enumerate(items)],
            "capacity_labels": [f"w={w}" for w in range(W + 1)]
        },
        "steps": steps
    }


def _solve_knapsack_backtracking(items, capacity, max_steps):
    n = len(items)
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    best_value = 0
    best_selection = []
    
    nodes_tree = []

    def dfs(index, current_weight, current_value, current_items, parent_id, branch_label):
        nonlocal step_id, node_counter, states_explored, states_pruned, best_value, best_selection
        
        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "item_index": index,
            "branch": branch_label,
            "current_weight": current_weight,
            "current_value": current_value,
            "status": "exploring",
            "depth": index,
            "selected_items": list(current_items)
        }
        nodes_tree.append(node_info)

        # Check capacity constraint
        if current_weight > capacity:
            states_pruned += 1
            node_info["status"] = "pruned_weight"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_overweight",
                    "node_id": node_id,
                    "parent_id": parent_id,
                    "description": f"PRUNED at Node {node_id} (Branch '{branch_label}'): Weight {current_weight} exceeds capacity {capacity}.",
                    "current_node": node_info,
                    "best_value": best_value,
                    "tree_node": node_info
                })
            return

        # Record valid exploration step
        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_explore",
                "action": "explore_node",
                "node_id": node_id,
                "parent_id": parent_id,
                "description": f"Exploring Node {node_id} (Depth {index}): Branch '{branch_label}', Weight={current_weight}/{capacity}, Value={current_value}.",
                "current_node": node_info,
                "best_value": best_value,
                "tree_node": node_info
            })

        if current_value > best_value:
            best_value = current_value
            best_selection = list(current_items)
            node_info["status"] = "new_best"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_update_best",
                    "action": "update_best_solution",
                    "node_id": node_id,
                    "description": f"NEW BEST SOLUTION found at Node {node_id}: Value = {best_value}, Weight = {current_weight}.",
                    "current_node": node_info,
                    "best_value": best_value,
                    "best_selection": best_selection
                })

        # Leaf node reached
        if index == n:
            return

        # Recursive Branch 1: INCLUDE item[index]
        item = items[index]
        dfs(index + 1, current_weight + item["weight"], current_value + item["value"], current_items + [item["id"]], node_id, f"+Item {index + 1} (W={item['weight']}, V={item['value']})")

        # Recursive Branch 2: EXCLUDE item[index]
        dfs(index + 1, current_weight, current_value, current_items, node_id, f"-Item {index + 1} (Skip)")

        # Backtracking step
        step_id += 1
        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_backtrack",
                "action": "backtrack",
                "node_id": node_id,
                "description": f"Backtracking from Node {node_id} (Item {index + 1}) to parent Node {parent_id}.",
                "current_node": node_info,
                "best_value": best_value
            })

    # Start DFS
    dfs(0, 0, 0, [], None, "Root")

    selected_objs = [it for it in items if it["id"] in best_selection]
    total_wt = sum(it["weight"] for it in selected_objs)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "backtracking_complete",
        "description": f"Backtracking completed. Optimal Value = {best_value}, States Explored = {states_explored}, Pruned = {states_pruned}.",
        "best_value": best_value,
        "selected_items": best_selection
    })

    return {
        "problem": "0/1 Knapsack",
        "algorithm": "backtracking",
        "algorithm_name": "Backtracking",
        "is_optimal": True,
        "quality_label": "Optimal Solution (Guaranteed)",
        "solution": {
            "selected_indices": best_selection,
            "selected_items": selected_objs,
            "total_value": best_value,
            "total_weight": total_wt,
            "capacity": capacity
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Search_Tree",
            "nodes_count": len(nodes_tree),
            "tree_nodes": nodes_tree[:500]
        },
        "steps": steps
    }


def _solve_knapsack_branch_and_bound(items, capacity, max_steps):
    sorted_items = sorted(items, key=lambda it: it["ratio"], reverse=True)
    n = len(sorted_items)
    
    steps = []
    step_id = 0
    node_counter = 0
    states_explored = 0
    states_pruned = 0
    best_value = 0
    best_selection = []
    nodes_tree = []

    def calculate_upper_bound(index, current_weight, current_value):
        """Fractional knapsack relaxation upper bound"""
        if current_weight > capacity:
            return 0
        bound = float(current_value)
        total_w = current_weight
        for j in range(index, n):
            it = sorted_items[j]
            if total_w + it["weight"] <= capacity:
                total_w += it["weight"]
                bound += it["value"]
            else:
                remain = capacity - total_w
                if it["weight"] > 0:
                    bound += it["value"] * (remain / it["weight"])
                break
        return bound

    def branch_and_bound_dfs(index, current_weight, current_value, current_items, parent_id, branch_label):
        nonlocal step_id, node_counter, states_explored, states_pruned, best_value, best_selection

        node_id = node_counter
        node_counter += 1
        states_explored += 1
        step_id += 1

        bound = calculate_upper_bound(index, current_weight, current_value)

        node_info = {
            "id": node_id,
            "parent_id": parent_id,
            "item_index": index,
            "branch": branch_label,
            "current_weight": current_weight,
            "current_value": current_value,
            "upper_bound": round(bound, 2),
            "status": "exploring",
            "depth": index,
            "selected_items": list(current_items)
        }
        nodes_tree.append(node_info)

        # Capacity overflow pruning
        if current_weight > capacity:
            states_pruned += 1
            node_info["status"] = "pruned_weight"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_capacity",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Weight {current_weight} > Capacity {capacity}.",
                    "current_node": node_info,
                    "best_value": best_value,
                    "tree_node": node_info
                })
            return

        # Update best solution if current value exceeds best
        if current_value > best_value:
            best_value = current_value
            best_selection = list(current_items)
            node_info["status"] = "new_best"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_update_best",
                    "action": "update_best",
                    "node_id": node_id,
                    "description": f"NEW BEST SOLUTION at Node {node_id}: Value = {best_value}, Weight = {current_weight}, Bound = {round(bound, 1)}.",
                    "current_node": node_info,
                    "best_value": best_value,
                    "best_selection": best_selection
                })

        # Bound pruning: if upper bound <= best known value
        if bound <= best_value and node_id != 0:
            states_pruned += 1
            node_info["status"] = "pruned_bound"
            if len(steps) < max_steps:
                steps.append({
                    "step_id": step_id,
                    "type": "tree_prune",
                    "action": "prune_bound",
                    "node_id": node_id,
                    "description": f"PRUNED Node {node_id}: Upper Bound ({round(bound, 1)}) <= Best Value ({best_value}). Subtree cannot produce a better solution.",
                    "current_node": node_info,
                    "best_value": best_value,
                    "tree_node": node_info
                })
            return

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "tree_explore",
                "action": "explore_node",
                "node_id": node_id,
                "description": f"Exploring Node {node_id} (Depth {index}): Value={current_value}, Bound={round(bound, 1)}, Best={best_value}.",
                "current_node": node_info,
                "best_value": best_value,
                "tree_node": node_info
            })

        if index == n:
            return

        # Explore Include branch first (heuristic order)
        item = sorted_items[index]
        branch_and_bound_dfs(index + 1, current_weight + item["weight"], current_value + item["value"], current_items + [item["id"]], node_id, f"+Item {item['id']+1} (W={item['weight']}, V={item['value']})")

        # Explore Exclude branch
        branch_and_bound_dfs(index + 1, current_weight, current_value, current_items, node_id, f"-Item {item['id']+1} (Skip)")

    # Execute B&B
    initial_ub = calculate_upper_bound(0, 0, 0)
    branch_and_bound_dfs(0, 0, 0, [], None, f"Root (UB={round(initial_ub, 1)})")

    selected_objs = [it for it in items if it["id"] in best_selection]
    total_wt = sum(it["weight"] for it in selected_objs)

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "bnb_complete",
        "description": f"Branch & Bound completed. Optimal Value = {best_value}, Explored = {states_explored}, Pruned = {states_pruned}.",
        "best_value": best_value,
        "selected_items": best_selection
    })

    return {
        "problem": "0/1 Knapsack",
        "algorithm": "branch_and_bound",
        "algorithm_name": "Branch and Bound",
        "is_optimal": True,
        "quality_label": "Optimal Solution (Guaranteed)",
        "solution": {
            "selected_indices": best_selection,
            "selected_items": selected_objs,
            "total_value": best_value,
            "total_weight": total_wt,
            "capacity": capacity
        },
        "statistics": {
            "states_explored": states_explored,
            "states_pruned": states_pruned,
            "total_nodes_generated": node_counter,
            "max_tree_depth": n,
            "iterations": states_explored
        },
        "data_structures": {
            "type": "Branch_and_Bound_Tree",
            "nodes_count": len(nodes_tree),
            "tree_nodes": nodes_tree[:500]
        },
        "steps": steps
    }


def _solve_knapsack_greedy(items, capacity, max_steps):
    sorted_items = sorted(items, key=lambda it: it["ratio"], reverse=True)
    steps = []
    step_id = 0
    selected_items = []
    total_val = 0
    total_wt = 0

    steps.append({
        "step_id": step_id,
        "type": "greedy_init",
        "action": "sort_by_ratio",
        "description": f"Sorted all {len(items)} items descending by Value/Weight density ratio.",
        "sorted_items": sorted_items,
        "current_weight": 0,
        "current_value": 0,
        "remaining_capacity": capacity
    })

    for idx, item in enumerate(sorted_items):
        step_id += 1
        if total_wt + item["weight"] <= capacity:
            total_wt += item["weight"]
            total_val += item["value"]
            selected_items.append(item)
            decision = "ACCEPTED"
            reason = f"Item {item['id'] + 1} (W={item['weight']}, V={item['value']}, Ratio={item['ratio']}) fits. Added to knapsack."
        else:
            decision = "REJECTED"
            reason = f"Item {item['id'] + 1} (W={item['weight']}, V={item['value']}) exceeds remaining capacity ({capacity - total_wt}). Skipped."

        if len(steps) < max_steps:
            steps.append({
                "step_id": step_id,
                "type": "greedy_step",
                "action": f"candidate_{decision.lower()}",
                "decision": decision,
                "item": item,
                "description": f"Candidate {idx + 1}/{len(sorted_items)}: {reason}",
                "current_weight": total_wt,
                "current_value": total_val,
                "remaining_capacity": capacity - total_wt,
                "selected_items": [it["id"] for it in selected_items]
            })

    steps.append({
        "step_id": step_id + 1,
        "type": "complete",
        "action": "greedy_complete",
        "description": f"Greedy heuristic complete. Final Value = {total_val}, Total Weight = {total_wt}/{capacity}.",
        "current_weight": total_wt,
        "current_value": total_val,
        "selected_items": [it["id"] for it in selected_items]
    })

    return {
        "problem": "0/1 Knapsack",
        "algorithm": "greedy",
        "algorithm_name": "Greedy Heuristic",
        "is_optimal": False,
        "quality_label": "Approximate Solution (Heuristic)",
        "solution": {
            "selected_indices": [it["id"] for it in selected_items],
            "selected_items": selected_items,
            "total_value": total_val,
            "total_weight": total_wt,
            "capacity": capacity
        },
        "statistics": {
            "states_explored": len(items),
            "states_pruned": 0,
            "total_nodes_generated": len(items),
            "max_tree_depth": len(items),
            "iterations": len(items)
        },
        "data_structures": {
            "type": "Sorted_Array",
            "sorted_items": sorted_items
        },
        "steps": steps
    }
