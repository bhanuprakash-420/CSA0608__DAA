"""
Reports package for NP-Complete Problem Visualizer & Solver
"""

from .pdf_generator import generate_pdf_report

__all__ = ["generate_pdf_report"]
