"""
PDF Report Generator for DAA Project
Generates comprehensive, formatted PDF documentation for academic presentations, viva, and project evaluations.
"""

import io
import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY


def generate_pdf_report(report_data):
    """
    Generates a high-quality PDF report from execution/comparison data.
    Returns bytes of the generated PDF file.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()
    
    # Custom styles
    primary_color = colors.HexColor("#0f172a")     # Deep slate
    accent_color = colors.HexColor("#2563eb")      # Blue
    secondary_color = colors.HexColor("#475569")   # Muted slate
    highlight_color = colors.HexColor("#059669")   # Emerald
    border_color = colors.HexColor("#cbd5e1")      # Slate 300
    bg_light = colors.HexColor("#f8fafc")          # Slate 50

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=primary_color,
        alignment=TA_CENTER,
        fontName="Helvetica-Bold",
        spaceAfter=4
    )

    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontSize=11,
        leading=14,
        textColor=secondary_color,
        alignment=TA_CENTER,
        fontName="Helvetica",
        spaceAfter=15
    )

    heading2_style = ParagraphStyle(
        'Heading2',
        parent=styles['Heading2'],
        fontSize=13,
        leading=16,
        textColor=accent_color,
        fontName="Helvetica-Bold",
        spaceBefore=12,
        spaceAfter=6
    )

    body_style = ParagraphStyle(
        'BodyText',
        parent=styles['Normal'],
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor("#1e293b"),
        fontName="Helvetica",
        alignment=TA_JUSTIFY
    )

    badge_style = ParagraphStyle(
        'Badge',
        parent=styles['Normal'],
        fontSize=8,
        leading=10,
        textColor=colors.white,
        fontName="Helvetica-Bold",
        alignment=TA_CENTER
    )

    table_header_style = ParagraphStyle(
        'TableHeader',
        parent=styles['Normal'],
        fontSize=9,
        leading=11,
        textColor=colors.white,
        fontName="Helvetica-Bold",
        alignment=TA_CENTER
    )

    table_cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#1e293b"),
        fontName="Helvetica",
        alignment=TA_CENTER
    )

    story = []

    # Title Header
    story.append(Paragraph("DESIGN AND ANALYSIS OF ALGORITHMS (DAA)", subtitle_style))
    story.append(Paragraph("NP-Complete Problem Visualizer & Solver Report", title_style))
    story.append(Paragraph("Design & Implementation of NP-Complete Visualizer Using Efficient Algorithmic Techniques", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=accent_color, spaceBefore=4, spaceAfter=12))

    # Meta block
    now_str = datetime.datetime.now().strftime("%B %d, %Y - %H:%M:%S")
    problem_name = report_data.get("problem_name", report_data.get("problem", "N/A"))
    
    meta_data = [
        [
            Paragraph("<b>Problem:</b> " + str(problem_name), body_style),
            Paragraph("<b>Generated:</b> " + now_str, body_style)
        ],
        [
            Paragraph("<b>Evaluation Mode:</b> " + ("Comparative Evaluation" if "algorithms" in report_data else "Single Algorithm Run"), body_style),
            Paragraph("<b>Platform:</b> Python DAA Visualizer & Benchmarking Engine", body_style)
        ]
    ]
    meta_table = Table(meta_data, colWidths=[260, 270])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg_light),
        ('BOX', (0, 0), (-1, -1), 0.5, border_color),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, border_color),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 10))

    # Section 1: Problem Description
    story.append(Paragraph("1. Problem Statement & Mathematical Formulation", heading2_style))
    
    problem_key = report_data.get("problem", "").lower()
    if "knapsack" in problem_key:
        desc_text = (
            "<b>0/1 Knapsack Problem:</b> Given a set of <i>N</i> items, each with a positive weight <i>w<sub>i</sub></i> and value <i>v<sub>i</sub></i>, "
            "and a knapsack of capacity <i>W</i>, determine a binary subset <i>x<sub>i</sub> ∈ {0, 1}</i> that maximizes total value "
            "<b>∑ (v<sub>i</sub> · x<sub>i</sub>)</b> subject to the capacity constraint <b>∑ (w<sub>i</sub> · x<sub>i</sub>) ≤ W</b>. "
            "The 0/1 Knapsack problem is weakly NP-complete."
        )
    elif "tsp" in problem_key:
        desc_text = (
            "<b>Travelling Salesman Problem (TSP):</b> Given a list of <i>N</i> cities and a pairwise distance matrix <i>D[i][j]</i>, "
            "find the permutation tour <i>π = (c<sub>1</sub>, c<sub>2</sub>, ..., c<sub>N</sub>, c<sub>1</sub>)</i> that visits every city "
            "exactly once and returns to the origin city with minimum total tour length <b>∑ D[c<sub>k</sub>][c<sub>k+1</sub>]</b>. "
            "TSP is strongly NP-hard and its decision version is NP-complete."
        )
    elif "subset" in problem_key:
        desc_text = (
            "<b>Subset Sum Problem:</b> Given a multiset <i>S = {s<sub>1</sub>, s<sub>2</sub>, ..., s<sub>N</sub>}</i> of positive integers and a target integer <i>T</i>, "
            "determine whether there exists a subset <i>S' ⊆ S</i> such that the sum of elements in <i>S'</i> equals <i>T</i>: "
            "<b>∑<sub>s ∈ S'</sub> s = T</b>. Subset Sum is a classic NP-complete problem (Karp's 21 NP-complete problems)."
        )
    elif "queen" in problem_key:
        desc_text = (
            "<b>N-Queens Problem:</b> Place <i>N</i> non-attacking chess queens on an <i>N × N</i> chessboard such that no two queens "
            "share the same row, column, or diagonal. As a generalized constraint satisfaction problem (CSP), determining solvability and counting "
            "valid configurations is NP-complete."
        )
    else:
        desc_text = "NP-Complete algorithmic instance analyzed using exact and heuristic exploration techniques."

    story.append(Paragraph(desc_text, body_style))
    story.append(Spacer(1, 10))

    # Section 2: Input Instance Parameters
    story.append(Paragraph("2. Input Instance Specification", heading2_style))
    input_params = report_data.get("input_params", {})
    input_summary_text = report_data.get("input_summary", "")

    if "knapsack" in problem_key:
        w_list = input_params.get("weights", [])
        v_list = input_params.get("values", [])
        cap = input_params.get("capacity", 0)
        items_preview = ", ".join([f"I{i+1}:(W={w_list[i]}, V={v_list[i]})" for i in range(min(len(w_list), 10))])
        if len(w_list) > 10:
            items_preview += f" ... (+{len(w_list)-10} more)"
        input_desc = f"<b>Total Items (N):</b> {len(w_list)} | <b>Knapsack Capacity (W):</b> {cap}<br/><b>Items:</b> {items_preview}"
    elif "tsp" in problem_key:
        mat = input_params.get("matrix", [])
        input_desc = f"<b>Number of Cities (N):</b> {len(mat)} | <b>Distance Matrix:</b> {len(mat)} × {len(mat)} symmetric/asymmetric distance grid."
    elif "subset" in problem_key:
        nums = input_params.get("numbers", [])
        targ = input_params.get("target", 0)
        input_desc = f"<b>Set Elements (N={len(nums)}):</b> {nums} | <b>Target Sum (T):</b> {targ}"
    elif "queen" in problem_key:
        n_val = input_params.get("n", 8)
        input_desc = f"<b>Board Dimension:</b> {n_val} × {n_val} ({n_val*n_val} squares)"
    else:
        input_desc = f"<b>Parameters:</b> {input_summary_text}"

    story.append(Paragraph(input_desc, body_style))
    story.append(Spacer(1, 10))

    # Section 3: Performance Benchmarking Table
    story.append(Paragraph("3. Empirical Algorithm Performance Benchmarks", heading2_style))

    # Compile algorithms results
    algo_results = []
    if "results" in report_data and isinstance(report_data["results"], list):
        algo_results = report_data["results"]
    elif "result" in report_data and isinstance(report_data["result"], dict):
        algo_results = [report_data["result"]]
    elif "single_run" in report_data:
        algo_results = [report_data["single_run"]]

    if not algo_results:
        # Construct fallback single result from report_data
        algo_results = [{
            "algorithm_name": report_data.get("algorithm_name", "Algorithm"),
            "quality_label": report_data.get("quality_label", "Standard"),
            "is_optimal": report_data.get("is_optimal", True),
            "statistics": {
                "execution_time_ms": report_data.get("execution_time_ms", 0.0),
                "memory_kb": report_data.get("memory_kb", 0.0),
                "states_explored": report_data.get("states_explored", 0),
                "states_pruned": report_data.get("states_pruned", 0)
            },
            "solution": report_data.get("solution", {})
        }]

    # Table headers
    perf_table_data = [
        [
            Paragraph("<b>Algorithm</b>", table_header_style),
            Paragraph("<b>Type / Quality</b>", table_header_style),
            Paragraph("<b>Exec Time</b>", table_header_style),
            Paragraph("<b>Memory (KB)</b>", table_header_style),
            Paragraph("<b>States Explored</b>", table_header_style),
            Paragraph("<b>States Pruned</b>", table_header_style),
            Paragraph("<b>Objective Value</b>", table_header_style),
        ]
    ]

    for res in algo_results:
        stats = res.get("statistics", {})
        sol = res.get("solution", {})
        
        # Calculate objective text
        if "total_value" in sol:
            obj_text = f"Val: {sol['total_value']}"
        elif "total_distance" in sol:
            obj_text = f"Dist: {sol['total_distance']}"
        elif "achieved_sum" in sol:
            obj_text = f"Sum: {sol['achieved_sum']} ({'Hit' if sol.get('is_achievable') else 'Miss'})"
        elif "total_solutions_found" in sol:
            obj_text = f"Sols: {sol['total_solutions_found']}"
        else:
            obj_text = "Found"

        quality_text = "Optimal" if res.get("is_optimal", True) else "Approximate"

        perf_table_data.append([
            Paragraph(str(res.get("algorithm_name", "Algorithm")), table_cell_style),
            Paragraph(quality_text, table_cell_style),
            Paragraph(f"{stats.get('execution_time_ms', 0.0):.3f} ms", table_cell_style),
            Paragraph(f"{stats.get('memory_kb', 0.0):.2f} KB", table_cell_style),
            Paragraph(str(stats.get("states_explored", 0)), table_cell_style),
            Paragraph(str(stats.get("states_pruned", 0)), table_cell_style),
            Paragraph(obj_text, table_cell_style)
        ])

    perf_table = Table(perf_table_data, colWidths=[110, 80, 65, 65, 70, 70, 70])
    perf_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), primary_color),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('BOX', (0, 0), (-1, -1), 0.5, border_color),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, border_color),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, bg_light]),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(perf_table)
    story.append(Spacer(1, 10))

    # Section 4: Theoretical Complexity Breakdown
    story.append(Paragraph("4. Theoretical Computational Complexity Analysis", heading2_style))

    complexity_data = [
        [
            Paragraph("<b>Algorithmic Technique</b>", table_header_style),
            Paragraph("<b>Time Complexity (Worst)</b>", table_header_style),
            Paragraph("<b>Space Complexity</b>", table_header_style),
            Paragraph("<b>Pruning / Optimization Mechanism</b>", table_header_style)
        ],
        [
            Paragraph("<b>Dynamic Programming</b>", table_cell_style),
            Paragraph("O(n · W) / Pseudo-polynomial", table_cell_style),
            Paragraph("O(n · W) or O(W)", table_cell_style),
            Paragraph("Optimal substructure & overlapping subproblems tabulation.", table_cell_style)
        ],
        [
            Paragraph("<b>Backtracking (DFS)</b>", table_cell_style),
            Paragraph("O(2ⁿ) / O(n!) Exponential", table_cell_style),
            Paragraph("O(n) Recursion Stack", table_cell_style),
            Paragraph("Constraint checking: prunes invalid state branches immediately.", table_cell_style)
        ],
        [
            Paragraph("<b>Branch and Bound</b>", table_cell_style),
            Paragraph("O(2ⁿ) Worst / Significantly reduced average", table_cell_style),
            Paragraph("O(2ⁿ) Priority Queue / Tree", table_cell_style),
            Paragraph("Mathematical Upper/Lower Bounds prune subtrees worse than incumbent.", table_cell_style)
        ],
        [
            Paragraph("<b>Greedy / Heuristic</b>", table_cell_style),
            Paragraph("O(n log n) / O(n²)", table_cell_style),
            Paragraph("O(n)", table_cell_style),
            Paragraph("Locally optimal choices without backtracking; yields fast approximations.", table_cell_style)
        ]
    ]

    complexity_table = Table(complexity_data, colWidths=[120, 110, 90, 210])
    complexity_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), secondary_color),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('BOX', (0, 0), (-1, -1), 0.5, border_color),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, border_color),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, bg_light]),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(complexity_table)
    story.append(Spacer(1, 10))

    # Section 5: Real-World Applications & Academic Conclusion
    story.append(Paragraph("5. Real-World Applications & DAA Project Conclusions", heading2_style))
    conclusion_text = (
        "<b>Real-World Applications:</b> NP-Complete problems form the foundation for critical real-world systems including: "
        "<b>1. Vehicle Routing & Logistics</b> (TSP optimization in supply chains), "
        "<b>2. Resource & Cargo Allocation</b> (0/1 Knapsack in financial portfolio management and cloud container scheduling), "
        "<b>3. Financial Auditing & Cryptography</b> (Subset sum in subset matching and cryptographic protocols), and "
        "<b>4. AI Constraint Satisfaction & Scheduling</b> (N-Queens in timetable generation, VLSI circuit routing, and register allocation).<br/><br/>"
        "<b>Empirical Observations:</b><br/>"
        "• <i>Dynamic Programming</i> delivers guaranteed optimal solutions in pseudo-polynomial time when capacity/target values are moderate, but suffers memory explosion when target dimensions become exponential.<br/>"
        "• <i>Branch and Bound</i> significantly outperforms pure Backtracking by utilizing mathematical relaxations (e.g. fractional bounds, forward checking) to prune vast portions of the exponential state space.<br/>"
        "• <i>Greedy Heuristics & Local Search</i> execute in milliseconds with minimal memory footprint, making them indispensable for large-scale industrial instances where approximate solutions suffice."
    )
    story.append(Paragraph(conclusion_text, body_style))
    story.append(Spacer(1, 12))

    # Footer callout
    footer_text = f"<b>DAA B.Tech Project</b> | NP-Complete Problem Visualizer and Solver | Evaluation Copy | Page 1 of 1"
    story.append(Paragraph(footer_text, ParagraphStyle('Footer', parent=styles['Normal'], fontSize=7.5, textColor=secondary_color, alignment=TA_CENTER)))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
