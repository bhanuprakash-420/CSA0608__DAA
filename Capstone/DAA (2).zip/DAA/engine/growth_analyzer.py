"""
Input Size Scalability & Growth Analyzer
Measures actual running time and memory over increasing input sizes (N) to demonstrate NP-completeness growth curves.
"""

import random
import time
import math
from .benchmark import run_benchmarked_solver


def generate_synthetic_instance(problem, size, seed=42):
    rng = random.Random(seed + size)
    
    if problem == "knapsack":
        weights = [rng.randint(2, 20) for _ in range(size)]
        values = [rng.randint(10, 100) for _ in range(size)]
        capacity = int(sum(weights) * 0.5)
        return {"weights": weights, "values": values, "capacity": max(1, capacity)}

    elif problem == "tsp":
        # Generate random 2D coordinate points and compute Euclidean distance matrix
        coords = []
        for _ in range(size):
            coords.append([rng.randint(20, 480), rng.randint(20, 480)])
        matrix = [[0] * size for _ in range(size)]
        for i in range(size):
            for j in range(size):
                if i != j:
                    d = math.hypot(coords[i][0] - coords[j][0], coords[i][1] - coords[j][1])
                    matrix[i][j] = max(1, int(round(d)))
        return {"matrix": matrix, "coordinates": coords}

    elif problem == "subset_sum":
        numbers = [rng.randint(5, 50) for _ in range(size)]
        # Pick random subset to guarantee a target sum
        k = max(1, size // 3)
        chosen = rng.sample(numbers, k)
        target = sum(chosen)
        return {"numbers": numbers, "target": target}

    elif problem == "nqueens":
        return {"n": size, "find_all": False}

    else:
        raise ValueError(f"Unknown problem type '{problem}'.")


def run_growth_analysis(problem, algorithms, input_sizes, trials_per_size=1):
    """
    Executes multiple algorithms on instances of increasing size.
    Returns structured timeseries data for plotting growth charts.
    """
    results_by_algo = {algo: [] for algo in algorithms}
    
    for size in input_sizes:
        instance = generate_synthetic_instance(problem, size)
        
        for algo in algorithms:
            total_time_ms = 0
            total_mem_kb = 0
            total_states = 0
            is_optimal = True
            
            for t in range(trials_per_size):
                try:
                    res = run_benchmarked_solver(problem, algo, instance, max_steps=100)
                    total_time_ms += res["statistics"]["execution_time_ms"]
                    total_mem_kb += res["statistics"]["memory_kb"]
                    total_states += res["statistics"]["states_explored"]
                    is_optimal = res["is_optimal"]
                except Exception as e:
                    # If execution fails or exceeds timeout for large N
                    total_time_ms += 9999.0
                    total_mem_kb += 0
                    total_states += 0

            avg_time = round(total_time_ms / trials_per_size, 3)
            avg_mem = round(total_mem_kb / trials_per_size, 2)
            avg_states = int(total_states / trials_per_size)

            results_by_algo[algo].append({
                "input_size": size,
                "execution_time_ms": avg_time,
                "memory_kb": avg_mem,
                "states_explored": avg_states,
                "is_optimal": is_optimal
            })

    return {
        "problem": problem,
        "input_sizes": input_sizes,
        "series": results_by_algo
    }
