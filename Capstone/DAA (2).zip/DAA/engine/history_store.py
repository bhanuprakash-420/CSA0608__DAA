"""
Persistent Execution History Store using SQLite
Stores run records, aggregates performance statistics, and provides search and filtering.
"""

import sqlite3
import json
import os
import datetime


class HistoryStore:
    def __init__(self, db_path="history.db"):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS executions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    problem TEXT NOT NULL,
                    problem_name TEXT NOT NULL,
                    algorithm TEXT NOT NULL,
                    algorithm_name TEXT NOT NULL,
                    input_size INTEGER NOT NULL,
                    input_summary TEXT,
                    execution_time_ms REAL NOT NULL,
                    execution_time_us REAL NOT NULL,
                    memory_kb REAL NOT NULL,
                    states_explored INTEGER NOT NULL,
                    states_pruned INTEGER NOT NULL,
                    solution_summary TEXT,
                    is_optimal INTEGER NOT NULL,
                    quality_label TEXT,
                    full_result_json TEXT
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def record_execution(self, problem, algorithm, input_params, result):
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        stats = result.get("statistics", {})
        sol = result.get("solution", {})

        # Compute input summary and size
        if problem == "knapsack":
            input_size = len(input_params.get("weights", []))
            input_summary = f"N={input_size} items, Capacity={input_params.get('capacity', 0)}"
            sol_summary = f"Value={sol.get('total_value', 0)}, Weight={sol.get('total_weight', 0)}"
            problem_name = "0/1 Knapsack"
        elif problem == "tsp":
            input_size = len(input_params.get("matrix", []))
            input_summary = f"N={input_size} cities"
            sol_summary = f"Distance={sol.get('total_distance', 0)}, Tour={sol.get('tour_names', [])}"
            problem_name = "Travelling Salesman Problem"
        elif problem == "subset_sum":
            input_size = len(input_params.get("numbers", []))
            input_summary = f"N={input_size} numbers, Target={input_params.get('target', 0)}"
            sol_summary = f"Solvable={sol.get('is_achievable', False)}, Subset={sol.get('selected_subset', [])}"
            problem_name = "Subset Sum"
        elif problem == "nqueens":
            input_size = input_params.get("n", 8)
            input_summary = f"N={input_size}x{input_size} board"
            sol_summary = f"Solutions Found={sol.get('total_solutions_found', 0)}"
            problem_name = "N-Queens"
        else:
            input_size = 0
            input_summary = str(input_params)[:50]
            sol_summary = str(sol)[:50]
            problem_name = problem

        # Strip massive step array from stored json to keep db lightweight
        stored_result = dict(result)
        if "steps" in stored_result and len(stored_result["steps"]) > 100:
            stored_result["steps"] = stored_result["steps"][:100]

        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO executions (
                    timestamp, problem, problem_name, algorithm, algorithm_name,
                    input_size, input_summary, execution_time_ms, execution_time_us,
                    memory_kb, states_explored, states_pruned, solution_summary,
                    is_optimal, quality_label, full_result_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                now_str,
                problem,
                problem_name,
                algorithm,
                result.get("algorithm_name", algorithm),
                input_size,
                input_summary,
                stats.get("execution_time_ms", 0.0),
                stats.get("execution_time_us", 0.0),
                stats.get("memory_kb", 0.0),
                stats.get("states_explored", 0),
                stats.get("states_pruned", 0),
                sol_summary,
                1 if result.get("is_optimal", False) else 0,
                result.get("quality_label", "Standard"),
                json.dumps(stored_result)
            ))
            conn.commit()
            return cursor.lastrowid
        finally:
            conn.close()

    def get_executions(self, problem=None, algorithm=None, search_query=None, limit=100, offset=0):
        query = "SELECT id, timestamp, problem, problem_name, algorithm, algorithm_name, input_size, input_summary, execution_time_ms, execution_time_us, memory_kb, states_explored, states_pruned, solution_summary, is_optimal, quality_label FROM executions WHERE 1=1"
        params = []

        if problem and problem != "all":
            query += " AND problem = ?"
            params.append(problem)

        if algorithm and algorithm != "all":
            query += " AND algorithm = ?"
            params.append(algorithm)

        if search_query:
            query += " AND (problem_name LIKE ? OR algorithm_name LIKE ? OR input_summary LIKE ? OR solution_summary LIKE ?)"
            wildcard = f"%{search_query}%"
            params.extend([wildcard, wildcard, wildcard, wildcard])

        query += " ORDER BY id DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def get_execution_detail(self, execution_id):
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM executions WHERE id = ?", (execution_id,))
            row = cursor.fetchone()
            if not row:
                return None
            data = dict(row)
            if data.get("full_result_json"):
                data["full_result"] = json.loads(data["full_result_json"])
            return data
        finally:
            conn.close()

    def delete_execution(self, execution_id):
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM executions WHERE id = ?", (execution_id,))
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    def clear_history(self):
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM executions")
            conn.commit()
        finally:
            conn.close()

    def get_summary_stats(self):
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM executions")
            total_runs = cursor.fetchone()[0]

            cursor.execute("SELECT AVG(execution_time_ms) FROM executions")
            avg_time = cursor.fetchone()[0] or 0.0

            cursor.execute("SELECT AVG(memory_kb) FROM executions")
            avg_mem = cursor.fetchone()[0] or 0.0

            cursor.execute("""
                SELECT algorithm_name, COUNT(*) as count, AVG(execution_time_ms) as avg_time
                FROM executions
                GROUP BY algorithm_name
                ORDER BY avg_time ASC
                LIMIT 1
            """)
            best_algo_row = cursor.fetchone()
            best_algo = dict(best_algo_row) if best_algo_row else {"algorithm_name": "N/A", "avg_time": 0}

            cursor.execute("""
                SELECT problem, COUNT(*) as count
                FROM executions
                GROUP BY problem
            """)
            problems_dist = {row[0]: row[1] for row in cursor.fetchall()}

            return {
                "total_executions": total_runs,
                "average_execution_time_ms": round(avg_time, 3),
                "average_memory_kb": round(avg_mem, 2),
                "best_performing_algorithm": best_algo.get("algorithm_name", "N/A"),
                "problem_distribution": problems_dist,
                "problems_supported": 4,
                "algorithms_supported": 13
            }
        finally:
            conn.close()
