"""
High-Precision Benchmarking Engine
Tracks execution time (nanoseconds), memory usage (bytes via tracemalloc), and search state metrics.
"""

import time
import tracemalloc
from algorithms.knapsack import solve_knapsack
from algorithms.tsp import solve_tsp
from algorithms.subset_sum import solve_subset_sum
from algorithms.nqueens import solve_nqueens


def run_benchmarked_solver(problem, algorithm, params, max_steps=2500):
    """
    Executes an algorithm solver under strict memory and time monitoring.
    Returns the solver result dictionary augmented with exact measured runtime metrics.
    """
    tracemalloc.start()
    t_start = time.perf_counter_ns()

    try:
        if problem == "knapsack":
            weights = params.get("weights", [])
            values = params.get("values", [])
            capacity = params.get("capacity", 0)
            result = solve_knapsack(weights, values, capacity, algorithm=algorithm, max_steps=max_steps)

        elif problem == "tsp":
            matrix = params.get("matrix", [])
            coordinates = params.get("coordinates", None)
            result = solve_tsp(matrix, coordinates=coordinates, algorithm=algorithm, max_steps=max_steps)

        elif problem == "subset_sum":
            numbers = params.get("numbers", [])
            target = params.get("target", 0)
            result = solve_subset_sum(numbers, target, algorithm=algorithm, max_steps=max_steps)

        elif problem == "nqueens":
            n = params.get("n", 8)
            find_all = params.get("find_all", False)
            result = solve_nqueens(n, algorithm=algorithm, find_all=find_all, max_steps=max_steps)

        else:
            raise ValueError(f"Unknown problem type '{problem}'.")

    finally:
        t_end = time.perf_counter_ns()
        current_mem, peak_mem = tracemalloc.get_traced_memory()
        tracemalloc.stop()

    exec_time_ns = max(1, t_end - t_start)
    exec_time_us = round(exec_time_ns / 1000.0, 3)
    exec_time_ms = round(exec_time_ns / 1_000_000.0, 3)
    memory_kb = round(peak_mem / 1024.0, 2)
    memory_mb = round(peak_mem / (1024.0 * 1024.0), 4)

    # Attach verified hardware performance measurements
    if "statistics" not in result:
        result["statistics"] = {}

    result["statistics"]["execution_time_ns"] = exec_time_ns
    result["statistics"]["execution_time_us"] = exec_time_us
    result["statistics"]["execution_time_ms"] = exec_time_ms
    result["statistics"]["memory_bytes"] = peak_mem
    result["statistics"]["memory_kb"] = memory_kb
    result["statistics"]["memory_mb"] = memory_mb

    return result
