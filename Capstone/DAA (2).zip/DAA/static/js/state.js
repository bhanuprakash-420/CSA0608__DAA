/**
 * Global Application State Management
 */

const AppState = {
  activeTab: 'dashboard',
  currentProblem: 'knapsack',
  currentAlgorithm: 'dynamic_programming',
  inputMode: 'sample', // 'sample' | 'manual' | 'upload'
  currentInputParams: {
    weights: [10, 20, 30, 25],
    values: [60, 100, 120, 90],
    capacity: 50
  },
  
  // Execution & Playback State
  executionResult: null,
  currentStepIndex: 0,
  isPlaying: false,
  playbackSpeedMs: 400,
  timerId: null,
  
  // Benchmark samples
  samples: {},
  
  // Subscribers
  listeners: {},

  on(event, callback) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
  },

  emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(cb => cb(data));
    }
  },

  setTab(tab) {
    this.activeTab = tab;
    this.emit('tabChanged', tab);
  },

  setProblem(problem) {
    this.currentProblem = problem;
    this.executionResult = null;
    this.currentStepIndex = 0;
    this.stopPlayback();
    this.emit('problemChanged', problem);
  },

  setAlgorithm(algorithm) {
    this.currentAlgorithm = algorithm;
    this.emit('algorithmChanged', algorithm);
  },

  setInputParams(params) {
    this.currentInputParams = params;
    this.executionResult = null;
    this.currentStepIndex = 0;
    this.stopPlayback();
    this.emit('inputParamsChanged', params);
  },

  setExecutionResult(result) {
    this.executionResult = result;
    this.currentStepIndex = 0;
    this.stopPlayback();
    this.emit('executionResultUpdated', result);
  },

  setStepIndex(index) {
    if (!this.executionResult || !this.executionResult.steps) return;
    const maxIdx = this.executionResult.steps.length - 1;
    const newIdx = Math.max(0, Math.min(index, maxIdx));
    this.currentStepIndex = newIdx;
    this.emit('stepChanged', {
      index: newIdx,
      step: this.executionResult.steps[newIdx],
      totalSteps: this.executionResult.steps.length
    });
  },

  nextStep() {
    if (!this.executionResult || !this.executionResult.steps) return;
    if (this.currentStepIndex < this.executionResult.steps.length - 1) {
      this.setStepIndex(this.currentStepIndex + 1);
    } else {
      this.stopPlayback();
    }
  },

  prevStep() {
    if (this.currentStepIndex > 0) {
      this.setStepIndex(this.currentStepIndex - 1);
    }
  },

  firstStep() {
    this.setStepIndex(0);
  },

  lastStep() {
    if (this.executionResult && this.executionResult.steps) {
      this.setStepIndex(this.executionResult.steps.length - 1);
    }
  },

  startPlayback() {
    if (!this.executionResult || !this.executionResult.steps) return;
    this.isPlaying = true;
    this.emit('playbackStateChanged', true);
    
    if (this.currentStepIndex >= this.executionResult.steps.length - 1) {
      this.currentStepIndex = 0;
    }

    const runLoop = () => {
      if (!this.isPlaying) return;
      if (this.currentStepIndex < this.executionResult.steps.length - 1) {
        this.nextStep();
        this.timerId = setTimeout(runLoop, this.playbackSpeedMs);
      } else {
        this.stopPlayback();
      }
    };

    this.timerId = setTimeout(runLoop, this.playbackSpeedMs);
  },

  stopPlayback() {
    this.isPlaying = false;
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.emit('playbackStateChanged', false);
  },

  togglePlayback() {
    if (this.isPlaying) {
      this.stopPlayback();
    } else {
      this.startPlayback();
    }
  },

  setPlaybackSpeed(speedMs) {
    this.playbackSpeedMs = speedMs;
    this.emit('speedChanged', speedMs);
  }
};
