/**
 * Input Size Scalability & Growth Analysis Module
 * Generates empirical execution time growth curves across increasing N to demonstrate NP-completeness.
 */

class GrowthAnalyzer {
  constructor() {
    this.timeGrowthChart = null;
    this.statesGrowthChart = null;
    this.initEventListeners();
  }

  initEventListeners() {
    document.getElementById('btn-run-growth')?.addEventListener('click', () => this.executeGrowthAnalysis());
  }

  async executeGrowthAnalysis() {
    const problem = document.getElementById('growth-problem-select')?.value || 'knapsack';
    
    // Get checked algorithms
    const checkboxes = document.querySelectorAll('.growth-algo-checkbox:checked');
    const algorithms = Array.from(checkboxes).map(cb => cb.value);

    if (algorithms.length === 0) {
      alert('Please select at least one algorithm for growth analysis.');
      return;
    }

    // Get input sizes
    const sizesInput = document.getElementById('growth-sizes-input')?.value || '4, 6, 8, 10, 12';
    const inputSizes = sizesInput.split(',').map(s => parseInt(s.trim())).filter(s => !isNaN(s) && s > 0);

    if (inputSizes.length < 2) {
      alert('Please provide at least 2 input sizes separated by commas (e.g. 4, 6, 8, 10, 12).');
      return;
    }

    const btn = document.getElementById('btn-run-growth');
    const spinner = document.getElementById('growth-spinner');
    if (btn) btn.disabled = true;
    if (spinner) spinner.classList.remove('hidden');

    try {
      const data = await API.getGrowth(problem, algorithms, inputSizes);
      this.renderGrowthCharts(data);
    } catch (err) {
      alert(`Growth analysis failed: ${err.message}`);
    } finally {
      if (btn) btn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
    }
  }

  renderGrowthCharts(data) {
    const inputSizes = data.input_sizes || [];
    const series = data.series || {};

    const colorPalette = [
      { border: '#06b6d4', bg: 'rgba(6, 182, 212, 0.2)' },
      { border: '#f43f5e', bg: 'rgba(244, 63, 94, 0.2)' },
      { border: '#10b981', bg: 'rgba(16, 185, 129, 0.2)' },
      { border: '#f59e0b', bg: 'rgba(245, 158, 11, 0.2)' },
      { border: '#8b5cf6', bg: 'rgba(139, 92, 246, 0.2)' }
    ];

    // Build datasets for Execution Time
    const timeDatasets = Object.keys(series).map((algoKey, idx) => {
      const color = colorPalette[idx % colorPalette.length];
      const dataPoints = series[algoKey].map(pt => pt.execution_time_ms);
      return {
        label: formatAlgoName(algoKey),
        data: dataPoints,
        borderColor: color.border,
        backgroundColor: color.bg,
        borderWidth: 2.5,
        tension: 0.3,
        pointRadius: 5,
        pointHoverRadius: 7
      };
    });

    // Build datasets for Explored States
    const stateDatasets = Object.keys(series).map((algoKey, idx) => {
      const color = colorPalette[idx % colorPalette.length];
      const dataPoints = series[algoKey].map(pt => pt.states_explored);
      return {
        label: formatAlgoName(algoKey),
        data: dataPoints,
        borderColor: color.border,
        backgroundColor: color.bg,
        borderWidth: 2,
        tension: 0.3,
        pointRadius: 4
      };
    });

    // Render Time Growth Chart
    const ctxTime = document.getElementById('chart-growth-time')?.getContext('2d');
    if (ctxTime) {
      if (this.timeGrowthChart) this.timeGrowthChart.destroy();
      this.timeGrowthChart = new Chart(ctxTime, {
        type: 'line',
        data: {
          labels: inputSizes.map(s => `N = ${s}`),
          datasets: timeDatasets
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } },
            tooltip: {
              backgroundColor: '#0f172a',
              titleColor: '#f8fafc',
              bodyColor: '#cbd5e1',
              borderColor: '#334155',
              borderWidth: 1
            }
          },
          scales: {
            x: {
              title: { display: true, text: 'Input Size (N)', color: '#94a3b8' },
              ticks: { color: '#94a3b8' },
              grid: { color: 'rgba(51, 65, 85, 0.3)' }
            },
            y: {
              title: { display: true, text: 'Execution Time (ms)', color: '#94a3b8' },
              ticks: { color: '#94a3b8', font: { family: 'Fira Code' } },
              grid: { color: 'rgba(51, 65, 85, 0.3)' }
            }
          }
        }
      });
    }

    // Render States Growth Chart
    const ctxStates = document.getElementById('chart-growth-states')?.getContext('2d');
    if (ctxStates) {
      if (this.statesGrowthChart) this.statesGrowthChart.destroy();
      this.statesGrowthChart = new Chart(ctxStates, {
        type: 'line',
        data: {
          labels: inputSizes.map(s => `N = ${s}`),
          datasets: stateDatasets
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } }
          },
          scales: {
            x: {
              title: { display: true, text: 'Input Size (N)', color: '#94a3b8' },
              ticks: { color: '#94a3b8' },
              grid: { color: 'rgba(51, 65, 85, 0.3)' }
            },
            y: {
              title: { display: true, text: 'States Explored', color: '#94a3b8' },
              ticks: { color: '#94a3b8', font: { family: 'Fira Code' } },
              grid: { color: 'rgba(51, 65, 85, 0.3)' }
            }
          }
        }
      });
    }

    // Show Results
    const resultsSec = document.getElementById('growth-results-section');
    if (resultsSec) resultsSec.classList.remove('hidden');
  }
}

function formatAlgoName(key) {
  const map = {
    'dynamic_programming': 'Dynamic Programming',
    'backtracking': 'Backtracking',
    'branch_and_bound': 'Branch and Bound',
    'greedy': 'Greedy Heuristic',
    'two_opt': '2-Opt Approx'
  };
  return map[key] || key;
}

window.GrowthAnalyzer = GrowthAnalyzer;
