/**
 * Main Application Controller
 * Coordinates UI tabs, dynamic input generation, algorithm execution, visualization playback, and dashboards.
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize Visualizers
  window.treeVisualizer = new TreeVisualizer('tree-visualizer-container');
  window.dpVisualizer = new DpVisualizer('dp-visualizer-container');
  window.tspVisualizer = new TspVisualizer('tsp-visualizer-container');
  window.chessboardVisualizer = new ChessboardVisualizer('chessboard-visualizer-container');
  window.greedyVisualizer = new GreedyVisualizer('greedy-visualizer-container');
  window.dataStructureVisualizer = new DataStructureVisualizer('data-structures-container');

  // Initialize Suites
  window.comparisonSuite = new ComparisonSuite();
  window.growthAnalyzer = new GrowthAnalyzer();

  // Load initial data
  await loadInitialData();

  // Bind Event Listeners
  initNavigation();
  initProblemSelection();
  initInputModeSwitching();
  initSolverExecution();
  initPlaybackControls();
  initKeyboardShortcuts();
  initPdfExport();

  // Initial render of input form and dashboard
  renderInputForm(AppState.currentProblem);
  refreshDashboardStats();
});

async function loadInitialData() {
  try {
    const samples = await API.getSamples();
    AppState.samples = samples;
    populateSampleDropdown(AppState.currentProblem);
  } catch (err) {
    console.error('Failed to load samples:', err);
  }
}

async function refreshDashboardStats() {
  try {
    const stats = await API.getStats();
    document.getElementById('stat-total-executions')?.replaceChildren(document.createTextNode(stats.total_executions || 0));
    document.getElementById('stat-avg-time')?.replaceChildren(document.createTextNode(`${(stats.average_execution_time_ms || 0).toFixed(2)} ms`));
    document.getElementById('stat-best-algo')?.replaceChildren(document.createTextNode(stats.best_performing_algorithm || 'N/A'));
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

function initNavigation() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      e.preventDefault();
      const targetTab = tab.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });

  // Action buttons
  document.getElementById('btn-nav-start')?.addEventListener('click', () => switchTab('solver'));
  document.getElementById('btn-nav-compare')?.addEventListener('click', () => switchTab('comparison'));
  document.getElementById('btn-nav-growth')?.addEventListener('click', () => switchTab('growth'));
  document.getElementById('btn-nav-complexity')?.addEventListener('click', () => switchTab('complexity'));
}

function switchTab(tabId) {
  AppState.setTab(tabId);

  // Update navbar styling
  document.querySelectorAll('.nav-tab').forEach(t => {
    if (t.getAttribute('data-tab') === tabId) {
      t.classList.add('active');
    } else {
      t.classList.remove('active');
    }
  });

  // Show/Hide tab content panels
  document.querySelectorAll('.tab-content').forEach(p => {
    if (p.id === `tab-${tabId}`) {
      p.classList.remove('hidden');
    } else {
      p.classList.add('hidden');
    }
  });

  if (tabId === 'history') {
    window.historyManager.loadHistory();
  } else if (tabId === 'dashboard') {
    refreshDashboardStats();
  }
}

function initProblemSelection() {
  // Problem dropdown in solver
  const problemSelect = document.getElementById('solver-problem-select');
  problemSelect?.addEventListener('change', (e) => {
    const prob = e.target.value;
    selectProblem(prob);
  });

  // Quick Problem Cards on Dashboard
  document.querySelectorAll('.btn-select-problem-card').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const prob = btn.getAttribute('data-problem');
      selectProblem(prob);
      switchTab('solver');
    });
  });
}

function selectProblem(problem) {
  AppState.setProblem(problem);
  
  // Sync dropdown
  const select = document.getElementById('solver-problem-select');
  if (select) select.value = problem;

  // Render proper input form & algorithm selectors
  renderInputForm(problem);
  renderAlgorithmSelector(problem);
  populateSampleDropdown(problem);
  updateComparisonProblem(problem);
  updateActiveVisualizerView();
}

function populateSampleDropdown(problem) {
  const sampleSelect = document.getElementById('solver-sample-select');
  if (!sampleSelect) return;

  sampleSelect.innerHTML = '<option value="">-- Choose a Benchmark Preset --</option>';
  const presets = (AppState.samples && AppState.samples[problem]) || [];

  presets.forEach((p, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = `${p.name} - ${p.description.slice(0, 45)}...`;
    sampleSelect.appendChild(opt);
  });

  sampleSelect.onchange = (e) => {
    const idx = e.target.value;
    if (idx !== '') {
      const preset = presets[idx];
      if (preset && preset.params) {
        AppState.setInputParams(preset.params);
        fillInputFormWithParams(problem, preset.params);
      }
    }
  };
}

function renderAlgorithmSelector(problem) {
  const container = document.getElementById('solver-algorithm-options');
  if (!container) return;

  const algoMap = {
    knapsack: [
      { id: 'dynamic_programming', name: 'Dynamic Programming', badge: 'Optimal O(nW)', desc: 'Tabulation table storing subproblems' },
      { id: 'backtracking', name: 'Backtracking', badge: 'Optimal O(2ⁿ)', desc: 'State tree DFS with capacity pruning' },
      { id: 'branch_and_bound', name: 'Branch and Bound', badge: 'Optimal (B&B)', desc: 'Fractional Knapsack upper bounding relaxation' },
      { id: 'greedy', name: 'Greedy Heuristic', badge: 'Approximate O(n log n)', desc: 'Ratio sorting with greedy picks' }
    ],
    tsp: [
      { id: 'branch_and_bound', name: 'Branch and Bound', badge: 'Optimal (B&B)', desc: '1-Tree lower bound tour pruning' },
      { id: 'backtracking', name: 'Backtracking', badge: 'Optimal O(n!)', desc: 'Permutation DFS tree' },
      { id: 'greedy', name: 'Greedy Heuristic', badge: 'Approximate O(n²)', desc: 'Nearest Neighbor city selection' },
      { id: 'two_opt', name: '2-Opt Approx', badge: 'Approximate (Local)', desc: 'Iterative edge-crossing 2-opt swaps' }
    ],
    subset_sum: [
      { id: 'dynamic_programming', name: 'Dynamic Programming', badge: 'Optimal O(n·T)', desc: 'Boolean subset sum grid' },
      { id: 'branch_and_bound', name: 'Branch and Bound', badge: 'Optimal (B&B)', desc: 'Sorted prefix/suffix feasibility bounds' },
      { id: 'backtracking', name: 'Backtracking', badge: 'Optimal O(2ⁿ)', desc: 'DFS with sum overshoot pruning' }
    ],
    nqueens: [
      { id: 'backtracking', name: 'Backtracking', badge: 'Optimal DFS', desc: 'Row-by-row placement with diagonal attack checks' },
      { id: 'branch_and_bound', name: 'Branch & Bound', badge: 'Forward Checking', desc: 'Lookahead domain starvation pruning' }
    ]
  };

  const algos = algoMap[problem] || algoMap.knapsack;
  AppState.setAlgorithm(algos[0].id);

  let html = '';
  algos.forEach((algo, idx) => {
    const isChecked = idx === 0;
    html += `
      <label class="p-3 rounded-lg border border-slate-800 bg-slate-900/60 hover:bg-slate-800/60 cursor-pointer flex items-center justify-between transition-colors">
        <div class="flex items-center gap-3">
          <input type="radio" name="solver_algorithm" value="${algo.id}" ${isChecked ? 'checked' : ''} class="w-4 h-4 text-cyan-500 bg-slate-900 border-slate-700">
          <div>
            <div class="text-xs font-semibold text-slate-200">${algo.name}</div>
            <div class="text-[11px] text-slate-400">${algo.desc}</div>
          </div>
        </div>
        <span class="px-2 py-0.5 rounded bg-slate-800 text-cyan-400 font-mono text-[10px]">${algo.badge}</span>
      </label>
    `;
  });

  container.innerHTML = html;

  // Listen for algorithm radio changes
  container.querySelectorAll('input[name="solver_algorithm"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      AppState.setAlgorithm(e.target.value);
      updateActiveVisualizerView();
    });
  });
}

function updateComparisonProblem(problem) {
  // Update problem select in comparison tab
  const compSelect = document.getElementById('comparison-problem-select');
  if (compSelect) compSelect.value = problem;

  // Update comparison algorithms checkboxes
  const compContainer = document.getElementById('comparison-algorithms-container');
  if (!compContainer) return;

  const algoMap = {
    knapsack: [
      { id: 'dynamic_programming', name: 'Dynamic Programming' },
      { id: 'backtracking', name: 'Backtracking' },
      { id: 'branch_and_bound', name: 'Branch and Bound' },
      { id: 'greedy', name: 'Greedy Heuristic' }
    ],
    tsp: [
      { id: 'branch_and_bound', name: 'Branch and Bound' },
      { id: 'backtracking', name: 'Backtracking' },
      { id: 'greedy', name: 'Greedy (Nearest Neighbor)' },
      { id: 'two_opt', name: '2-Opt Approximation' }
    ],
    subset_sum: [
      { id: 'dynamic_programming', name: 'Dynamic Programming' },
      { id: 'branch_and_bound', name: 'Branch and Bound' },
      { id: 'backtracking', name: 'Backtracking' }
    ],
    nqueens: [
      { id: 'backtracking', name: 'Backtracking' },
      { id: 'branch_and_bound', name: 'Branch and Bound (Forward Checking)' }
    ]
  };

  const algos = algoMap[problem] || algoMap.knapsack;
  let html = '';
  algos.forEach(a => {
    html += `
      <label class="flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs text-slate-300 cursor-pointer">
        <input type="checkbox" value="${a.id}" class="compare-algo-checkbox text-cyan-500 rounded bg-slate-950 border-slate-700" checked>
        <span>${a.name}</span>
      </label>
    `;
  });
  compContainer.innerHTML = html;
}

function renderInputForm(problem) {
  const formContainer = document.getElementById('dynamic-input-form');
  if (!formContainer) return;

  let html = '';

  if (problem === 'knapsack') {
    html = `
      <div class="flex flex-col gap-3">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label class="block text-xs text-slate-400 mb-1 font-medium">Weights (comma separated)</label>
            <input type="text" id="knapsack-weights" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none" value="10, 20, 30, 25">
          </div>
          <div>
            <label class="block text-xs text-slate-400 mb-1 font-medium">Values (comma separated)</label>
            <input type="text" id="knapsack-values" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none" value="60, 100, 120, 90">
          </div>
        </div>
        <div class="flex items-center justify-between gap-4">
          <div class="w-1/2">
            <label class="block text-xs text-slate-400 mb-1 font-medium">Knapsack Capacity (W)</label>
            <input type="number" id="knapsack-capacity" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none" value="50" min="1">
          </div>
          <div class="pt-4">
            <button type="button" id="btn-generate-random" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1.5">
              <i class="fas fa-shuffle"></i> Random Instance
            </button>
          </div>
        </div>
      </div>
    `;
  } else if (problem === 'tsp') {
    html = `
      <div class="flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <label class="block text-xs text-slate-400 font-medium">Pairwise Distance Matrix (Row by row, space/comma separated)</label>
          <button type="button" id="btn-generate-random" class="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1.5">
            <i class="fas fa-shuffle"></i> Random Cities
          </button>
        </div>
        <textarea id="tsp-matrix-input" rows="4" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none">0, 10, 15, 20
10, 0, 35, 25
15, 35, 0, 30
20, 25, 30, 0</textarea>
      </div>
    `;
  } else if (problem === 'subset_sum') {
    html = `
      <div class="flex flex-col gap-3">
        <div>
          <label class="block text-xs text-slate-400 mb-1 font-medium">Set of Positive Numbers (comma separated)</label>
          <input type="text" id="subset-numbers" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none" value="10, 7, 5, 18, 12">
        </div>
        <div class="flex items-center justify-between gap-4">
          <div class="w-1/2">
            <label class="block text-xs text-slate-400 mb-1 font-medium">Target Sum (T)</label>
            <input type="number" id="subset-target" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none" value="35" min="1">
          </div>
          <div class="pt-4">
            <button type="button" id="btn-generate-random" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1.5">
              <i class="fas fa-shuffle"></i> Random Numbers
            </button>
          </div>
        </div>
      </div>
    `;
  } else if (problem === 'nqueens') {
    html = `
      <div class="flex flex-col gap-3">
        <div>
          <div class="flex justify-between items-center mb-1">
            <label class="text-xs text-slate-400 font-medium">Board Size (N × N)</label>
            <span id="nqueens-val-display" class="font-mono text-cyan-400 text-xs font-bold">N = 8</span>
          </div>
          <input type="range" id="nqueens-slider" min="4" max="12" value="8" class="w-full bg-slate-800 rounded-lg">
        </div>
      </div>
    `;
  }

  formContainer.innerHTML = html;

  // Bind random generator
  document.getElementById('btn-generate-random')?.addEventListener('click', () => generateRandomInstance(problem));

  // Bind slider display
  const slider = document.getElementById('nqueens-slider');
  slider?.addEventListener('input', (e) => {
    document.getElementById('nqueens-val-display')?.replaceChildren(document.createTextNode(`N = ${e.target.value}`));
  });
}

function fillInputFormWithParams(problem, params) {
  if (problem === 'knapsack') {
    if (params.weights) document.getElementById('knapsack-weights').value = params.weights.join(', ');
    if (params.values) document.getElementById('knapsack-values').value = params.values.join(', ');
    if (params.capacity !== undefined) document.getElementById('knapsack-capacity').value = params.capacity;
  } else if (problem === 'tsp') {
    if (params.matrix) {
      document.getElementById('tsp-matrix-input').value = params.matrix.map(r => r.join(', ')).join('\n');
    }
  } else if (problem === 'subset_sum') {
    if (params.numbers) document.getElementById('subset-numbers').value = params.numbers.join(', ');
    if (params.target !== undefined) document.getElementById('subset-target').value = params.target;
  } else if (problem === 'nqueens') {
    if (params.n !== undefined) {
      const slider = document.getElementById('nqueens-slider');
      if (slider) slider.value = params.n;
      document.getElementById('nqueens-val-display')?.replaceChildren(document.createTextNode(`N = ${params.n}`));
    }
  }
}

function readInputForm(problem) {
  if (problem === 'knapsack') {
    const wStr = document.getElementById('knapsack-weights')?.value || '';
    const vStr = document.getElementById('knapsack-values')?.value || '';
    const cap = parseInt(document.getElementById('knapsack-capacity')?.value || '50');

    const weights = wStr.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
    const values = vStr.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));

    if (weights.length !== values.length) {
      throw new Error(`Weights count (${weights.length}) must equal Values count (${values.length}).`);
    }
    if (weights.length === 0) throw new Error('Please enter at least 1 item.');
    if (cap <= 0) throw new Error('Capacity must be > 0.');

    return { weights, values, capacity: cap };
  } else if (problem === 'tsp') {
    const text = document.getElementById('tsp-matrix-input')?.value || '';
    const lines = text.split('\n').filter(l => l.trim());
    const matrix = lines.map(line => {
      return line.split(/[\s,]+/).map(s => parseInt(s.trim())).filter(n => !isNaN(n));
    });

    if (matrix.length < 3) throw new Error('TSP requires at least 3 cities.');
    const n = matrix.length;
    for (let r of matrix) {
      if (r.length !== n) throw new Error(`Matrix must be square (${n}x${n}). Invalid row: [${r}]`);
    }
    return { matrix };
  } else if (problem === 'subset_sum') {
    const numStr = document.getElementById('subset-numbers')?.value || '';
    const target = parseInt(document.getElementById('subset-target')?.value || '35');
    const numbers = numStr.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));

    if (numbers.length === 0) throw new Error('Please provide at least 1 number.');
    if (target <= 0) throw new Error('Target sum must be > 0.');

    return { numbers, target };
  } else if (problem === 'nqueens') {
    const n = parseInt(document.getElementById('nqueens-slider')?.value || '8');
    return { n, find_all: false };
  }
}

function generateRandomInstance(problem) {
  if (problem === 'knapsack') {
    const n = 5 + Math.floor(Math.random() * 4);
    const weights = Array.from({ length: n }, () => 5 + Math.floor(Math.random() * 25));
    const values = Array.from({ length: n }, () => 20 + Math.floor(Math.random() * 100));
    const capacity = Math.floor(weights.reduce((a, b) => a + b, 0) * 0.55);

    document.getElementById('knapsack-weights').value = weights.join(', ');
    document.getElementById('knapsack-values').value = values.join(', ');
    document.getElementById('knapsack-capacity').value = capacity;
  } else if (problem === 'tsp') {
    const n = 5;
    const coords = [];
    for (let i = 0; i < n; i++) {
      coords.push([Math.floor(Math.random() * 400), Math.floor(Math.random() * 400)]);
    }
    const matrix = [];
    for (let i = 0; i < n; i++) {
      const row = [];
      for (let j = 0; j < n; j++) {
        if (i === j) row.push(0);
        else {
          const d = Math.round(Math.hypot(coords[i][0] - coords[j][0], coords[i][1] - coords[j][1]) / 10);
          row.push(Math.max(5, d));
        }
      }
      matrix.push(row);
    }
    document.getElementById('tsp-matrix-input').value = matrix.map(r => r.join(', ')).join('\n');
  } else if (problem === 'subset_sum') {
    const n = 6;
    const numbers = Array.from({ length: n }, () => 4 + Math.floor(Math.random() * 25));
    const target = numbers[0] + numbers[2] + (numbers[4] || 0);
    document.getElementById('subset-numbers').value = numbers.join(', ');
    document.getElementById('subset-target').value = target;
  }
}

function initInputModeSwitching() {
  const uploadInput = document.getElementById('solver-file-upload');
  uploadInput?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const data = await API.uploadValidate(file, AppState.currentProblem);
      if (data.success && data.params) {
        AppState.setInputParams(data.params);
        fillInputFormWithParams(AppState.currentProblem, data.params);
        alert(`Dataset '${file.name}' loaded and validated successfully!`);
      }
    } catch (err) {
      alert(`File upload failed: ${err.message}`);
    }
  });
}

function initSolverExecution() {
  document.getElementById('btn-run-solver')?.addEventListener('click', () => runSolver());
}

async function runSolver() {
  const problem = AppState.currentProblem;
  const algorithm = AppState.currentAlgorithm;

  let params;
  try {
    params = readInputForm(problem);
    AppState.setInputParams(params);
  } catch (err) {
    alert(`Input validation error: ${err.message}`);
    return;
  }

  const btn = document.getElementById('btn-run-solver');
  const statusBadge = document.getElementById('solver-status-badge');
  if (btn) btn.disabled = true;
  if (statusBadge) {
    statusBadge.textContent = 'Executing...';
    statusBadge.className = 'px-3 py-1 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs font-mono animate-pulse';
  }

  try {
    const result = await API.solve(problem, algorithm, params, 2500, true);
    AppState.setExecutionResult(result);

    // Update Result Summary Panel
    renderSolutionCard(result);

    // Update Visualizers
    updateActiveVisualizerView();

    // Set first step
    if (result.steps && result.steps.length > 0) {
      AppState.setStepIndex(0);
    }

    if (statusBadge) {
      statusBadge.textContent = 'Completed';
      statusBadge.className = 'px-3 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-mono';
    }

    // Refresh history
    refreshDashboardStats();
  } catch (err) {
    alert(`Execution failed: ${err.message}`);
    if (statusBadge) {
      statusBadge.textContent = 'Error';
      statusBadge.className = 'px-3 py-1 rounded bg-rose-950 text-rose-400 border border-rose-800 text-xs font-mono';
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}

function renderSolutionCard(result) {
  const card = document.getElementById('solution-results-card');
  if (!card) return;

  const sol = result.solution || {};
  const stats = result.statistics || {};

  let solutionTitle = 'Objective Solution';
  let solutionVal = '-';
  let detailsText = '';

  if (result.problem === '0/1 Knapsack') {
    solutionTitle = 'Maximum Knapsack Value';
    solutionVal = `${sol.total_value}`;
    detailsText = `Selected Items: [${sol.selected_indices.map(i => `Item ${i+1}`).join(', ')}] | Total Weight: ${sol.total_weight} / ${sol.capacity}`;
  } else if (result.problem === 'Travelling Salesman Problem') {
    solutionTitle = 'Shortest Tour Distance';
    solutionVal = `${sol.total_distance}`;
    detailsText = `Optimal Tour: ${sol.tour_names.join(' → ')}`;
  } else if (result.problem === 'Subset Sum') {
    solutionTitle = sol.is_achievable ? 'Target Sum Achieved' : 'Target Sum Unachievable';
    solutionVal = sol.is_achievable ? `${sol.achieved_sum}` : 'No Subset';
    detailsText = sol.is_achievable ? `Subset Elements: [${sol.selected_subset.join(', ')}]` : `Exhaustive search confirmed no subset sums to ${sol.target}.`;
  } else if (result.problem === 'N-Queens') {
    solutionTitle = 'N-Queens Solvability';
    solutionVal = sol.has_solution ? `${sol.total_solutions_found} Solution(s)` : 'No Solution';
    detailsText = sol.has_solution ? `Queen Column Positions: [${sol.solution_board.join(', ')}]` : `No non-attacking configuration exists for N=${sol.board_size}.`;
  }

  document.getElementById('sol-title')?.replaceChildren(document.createTextNode(solutionTitle));
  document.getElementById('sol-value')?.replaceChildren(document.createTextNode(solutionVal));
  document.getElementById('sol-details')?.replaceChildren(document.createTextNode(detailsText));

  // Performance metrics
  document.getElementById('metric-exec-time')?.replaceChildren(document.createTextNode(`${stats.execution_time_ms.toFixed(3)} ms`));
  document.getElementById('metric-memory')?.replaceChildren(document.createTextNode(`${stats.memory_kb.toFixed(2)} KB`));
  document.getElementById('metric-explored')?.replaceChildren(document.createTextNode(`${stats.states_explored}`));
  document.getElementById('metric-pruned')?.replaceChildren(document.createTextNode(`${stats.states_pruned}`));

  // Quality badge
  const qualityEl = document.getElementById('metric-quality');
  if (qualityEl) {
    qualityEl.textContent = result.quality_label;
    qualityEl.className = result.is_optimal ? 'px-2.5 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-semibold' : 'px-2.5 py-1 rounded bg-amber-950 border border-amber-800 text-amber-400 text-xs font-semibold';
  }

  card.classList.remove('hidden');
}

function updateActiveVisualizerView() {
  const problem = AppState.currentProblem;
  const algorithm = AppState.currentAlgorithm;
  const res = AppState.executionResult;

  // Visualizer views
  const treeView = document.getElementById('tree-visualizer-wrapper');
  const dpView = document.getElementById('dp-visualizer-wrapper');
  const tspView = document.getElementById('tsp-visualizer-wrapper');
  const chessView = document.getElementById('chessboard-visualizer-wrapper');
  const greedyView = document.getElementById('greedy-visualizer-wrapper');

  // Hide all
  [treeView, dpView, tspView, chessView, greedyView].forEach(v => v?.classList.add('hidden'));

  const dataStructs = res ? res.data_structures : null;
  const currentStep = res && res.steps ? res.steps[AppState.currentStepIndex] : null;

  if (algorithm === 'dynamic_programming') {
    dpView?.classList.remove('hidden');
    if (dataStructs) window.dpVisualizer.setData(dataStructs, currentStep);
  } else if (problem === 'tsp') {
    tspView?.classList.remove('hidden');
    if (dataStructs) window.tspVisualizer.setData(dataStructs, currentStep);
  } else if (problem === 'nqueens') {
    chessView?.classList.remove('hidden');
    if (dataStructs) window.chessboardVisualizer.setData(dataStructs, currentStep);
  } else if (algorithm === 'greedy' || algorithm === 'two_opt') {
    greedyView?.classList.remove('hidden');
    if (dataStructs) window.greedyVisualizer.setData(dataStructs, currentStep);
  } else {
    // Backtracking / Branch & Bound Tree
    treeView?.classList.remove('hidden');
    if (dataStructs) window.treeVisualizer.setData(dataStructs, currentStep);
  }

  // Update Data Structures Inspector Tab
  if (dataStructs) {
    window.dataStructureVisualizer.render(dataStructs, problem);
  }
}

function initPlaybackControls() {
  AppState.on('stepChanged', ({ index, step, totalSteps }) => {
    // Update counter
    const counter = document.getElementById('step-counter-display');
    const percent = Math.round(((index + 1) / totalSteps) * 100);
    if (counter) counter.textContent = `Step ${index + 1} / ${totalSteps} (${percent}%)`;

    // Update explanation HUD
    const descEl = document.getElementById('step-description-text');
    const badgeEl = document.getElementById('step-action-badge');
    if (descEl) descEl.textContent = step.description || 'Executing step...';
    if (badgeEl) badgeEl.textContent = (step.action || 'STEP').toUpperCase();

    // Push step to visualizers
    if (window.treeVisualizer) window.treeVisualizer.updateStep(step);
    if (window.dpVisualizer) window.dpVisualizer.updateStep(step);
    if (window.tspVisualizer) window.tspVisualizer.updateStep(step);
    if (window.chessboardVisualizer) window.chessboardVisualizer.updateStep(step);
    if (window.greedyVisualizer) window.greedyVisualizer.updateStep(step);
  });

  AppState.on('playbackStateChanged', (isPlaying) => {
    const playBtn = document.getElementById('btn-step-play');
    if (playBtn) {
      playBtn.innerHTML = isPlaying ? '<i class="fas fa-pause"></i> Pause' : '<i class="fas fa-play"></i> Play';
      playBtn.className = isPlaying ? 'px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded text-xs flex items-center gap-1' : 'px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded text-xs flex items-center gap-1';
    }
  });

  document.getElementById('btn-step-play')?.addEventListener('click', () => AppState.togglePlayback());
  document.getElementById('btn-step-next')?.addEventListener('click', () => AppState.nextStep());
  document.getElementById('btn-step-prev')?.addEventListener('click', () => AppState.prevStep());
  document.getElementById('btn-step-first')?.addEventListener('click', () => AppState.firstStep());
  document.getElementById('btn-step-last')?.addEventListener('click', () => AppState.lastStep());
  document.getElementById('btn-step-reset')?.addEventListener('click', () => {
    AppState.stopPlayback();
    AppState.setStepIndex(0);
  });

  // Speed slider
  document.getElementById('playback-speed-slider')?.addEventListener('input', (e) => {
    const delay = parseInt(e.target.value);
    AppState.setPlaybackSpeed(delay);
    document.getElementById('playback-speed-label')?.replaceChildren(document.createTextNode(`${delay}ms`));
  });
}

function initKeyboardShortcuts() {
  window.addEventListener('keydown', (e) => {
    if (['input', 'textarea'].includes(e.target.tagName.toLowerCase())) return;

    if (e.code === 'Space') {
      e.preventDefault();
      AppState.togglePlayback();
    } else if (e.code === 'ArrowRight') {
      e.preventDefault();
      AppState.nextStep();
    } else if (e.code === 'ArrowLeft') {
      e.preventDefault();
      AppState.prevStep();
    }
  });
}

function initPdfExport() {
  document.getElementById('btn-export-pdf')?.addEventListener('click', async () => {
    if (!AppState.executionResult) {
      alert('Please run an algorithm solver first before generating a report.');
      return;
    }

    try {
      const payload = {
        problem: AppState.currentProblem,
        problem_name: AppState.executionResult.problem,
        algorithm_name: AppState.executionResult.algorithm_name,
        is_optimal: AppState.executionResult.is_optimal,
        quality_label: AppState.executionResult.quality_label,
        statistics: AppState.executionResult.statistics,
        input_params: AppState.currentInputParams,
        solution: AppState.executionResult.solution
      };

      await API.downloadPdfReport(payload);
    } catch (err) {
      alert(`Report download failed: ${err.message}`);
    }
  });
}
