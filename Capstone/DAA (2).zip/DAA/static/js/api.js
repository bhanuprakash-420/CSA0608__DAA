/**
 * Backend API Client for NP-Complete Problem Visualizer & Solver
 */

const API = {
  async getSamples() {
    const res = await fetch('/api/samples');
    if (!res.ok) throw new Error('Failed to load sample datasets');
    return await res.json();
  },

  async getStats() {
    const res = await fetch('/api/stats');
    if (!res.ok) throw new Error('Failed to load dashboard statistics');
    return await res.json();
  },

  async solve(problem, algorithm, params, maxSteps = 2500, recordHistory = true) {
    const res = await fetch('/api/solve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        problem,
        algorithm,
        params,
        max_steps: maxSteps,
        record_history: recordHistory
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Solver execution failed');
    return data;
  },

  async compare(problem, algorithms, params) {
    const res = await fetch('/api/compare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        problem,
        algorithms,
        params
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Comparison execution failed');
    return data;
  },

  async getGrowth(problem, algorithms, inputSizes) {
    const res = await fetch('/api/growth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        problem,
        algorithms,
        input_sizes: inputSizes
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Growth analysis failed');
    return data;
  },

  async getHistory(problem = 'all', algorithm = 'all', search = '', limit = 100) {
    const params = new URLSearchParams({ problem, algorithm, search, limit });
    const res = await fetch(`/api/history?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to load history');
    return await res.json();
  },

  async getHistoryDetail(id) {
    const res = await fetch(`/api/history/${id}`);
    if (!res.ok) throw new Error('Failed to fetch history detail');
    return await res.json();
  },

  async deleteHistory(id) {
    const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete history record');
    return await res.json();
  },

  async clearHistory() {
    const res = await fetch('/api/history/clear', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to clear history');
    return await res.json();
  },

  async downloadPdfReport(reportPayload) {
    const res = await fetch('/api/report/pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reportPayload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'PDF generation failed');
    }
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DAA_NP_Report_${reportPayload.problem || 'Algorithm'}_${Date.now()}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  },

  async uploadValidate(file, problem) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('problem', problem);

    const res = await fetch('/api/upload-validate', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'File validation failed');
    return data;
  }
};
