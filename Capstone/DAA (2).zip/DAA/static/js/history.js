/**
 * Persistent History Manager
 * Manages run logs, filters, searches, detailed modal viewers, and database clearing.
 */

class HistoryManager {
  constructor() {
    this.historyList = [];
    this.initEventListeners();
  }

  initEventListeners() {
    document.getElementById('history-search-input')?.addEventListener('input', () => this.loadHistory());
    document.getElementById('history-problem-filter')?.addEventListener('change', () => this.loadHistory());
    document.getElementById('btn-clear-history')?.addEventListener('click', () => this.clearHistory());
    document.getElementById('btn-export-history-json')?.addEventListener('click', () => this.exportHistoryJson());
  }

  async loadHistory() {
    const search = document.getElementById('history-search-input')?.value || '';
    const problem = document.getElementById('history-problem-filter')?.value || 'all';

    try {
      const res = await API.getHistory(problem, 'all', search);
      this.historyList = res.history || [];
      this.renderHistoryTable();
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  }

  renderHistoryTable() {
    const tbody = document.getElementById('history-table-body');
    if (!tbody) return;

    if (this.historyList.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" class="p-8 text-center text-slate-500 text-sm">
            <i class="fas fa-clock-rotate-left text-3xl mb-2 block text-slate-600"></i>
            No execution history found. Run an algorithm solver to record runs.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = '';
    this.historyList.forEach(run => {
      const tr = document.createElement('tr');
      tr.className = 'border-b border-slate-800 hover:bg-slate-800/40 text-xs transition-colors';
      tr.innerHTML = `
        <td class="p-3 text-slate-400 font-mono">${run.timestamp}</td>
        <td class="p-3 font-semibold text-slate-200">${run.problem_name}</td>
        <td class="p-3 text-cyan-400">${run.algorithm_name}</td>
        <td class="p-3 font-mono text-slate-300">${run.input_size}</td>
        <td class="p-3 font-mono text-amber-400">${run.execution_time_ms.toFixed(3)} ms</td>
        <td class="p-3 font-mono text-purple-400">${run.memory_kb.toFixed(2)} KB</td>
        <td class="p-3 font-mono text-emerald-400">${run.solution_summary || '-'}</td>
        <td class="p-3 text-right">
          <div class="flex items-center justify-end gap-1.5">
            <button class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px]" onclick="window.historyManager.viewDetail(${run.id})" title="View Details">
              <i class="fas fa-eye"></i>
            </button>
            <button class="px-2 py-1 bg-rose-950 hover:bg-rose-900 text-rose-400 rounded text-[11px]" onclick="window.historyManager.deleteRecord(${run.id})" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  async viewDetail(id) {
    try {
      const data = await API.getHistoryDetail(id);
      if (!data) return;

      const modal = document.getElementById('history-modal');
      const content = document.getElementById('history-modal-content');
      if (modal && content) {
        content.textContent = JSON.stringify(data, null, 2);
        modal.classList.remove('hidden');
      }
    } catch (err) {
      alert(`Failed to load details: ${err.message}`);
    }
  }

  async deleteRecord(id) {
    if (!confirm('Are you sure you want to delete this execution log?')) return;
    try {
      await API.deleteHistory(id);
      this.loadHistory();
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  }

  async clearHistory() {
    if (!confirm('Are you sure you want to clear ALL execution logs? This cannot be undone.')) return;
    try {
      await API.clearHistory();
      this.loadHistory();
    } catch (err) {
      alert(`Clear failed: ${err.message}`);
    }
  }

  exportHistoryJson() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.historyList, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `DAA_NP_Execution_History_${Date.now()}.json`);
    dlAnchor.click();
    dlAnchor.remove();
  }
}

window.historyManager = new HistoryManager();
