/**
 * Data Structures Inspector & Visualizer
 * Visualizes Adjacency Matrices, 1D Weight/Value Arrays, State Stacks, and Bitmasks.
 */

class DataStructureVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
  }

  render(dataStructures, problem) {
    if (!this.container) return;

    if (!dataStructures) {
      this.container.innerHTML = `
        <div class="h-48 flex items-center justify-center text-slate-500 text-sm">
          No data structure loaded.
        </div>
      `;
      return;
    }

    let html = `<div class="flex flex-col gap-4">`;

    // Type Badge
    html += `
      <div class="flex items-center justify-between">
        <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Internal Data Structure</span>
        <span class="px-2.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-cyan-400 font-mono text-xs font-bold">
          ${dataStructures.type || 'Data Structure'}
        </span>
      </div>
    `;

    if (dataStructures.matrix) {
      // 2D Adjacency Matrix
      const matrix = dataStructures.matrix;
      const n = matrix.length;
      html += `
        <div class="overflow-x-auto max-h-[300px] border border-slate-800 rounded-lg p-2 bg-slate-950 shadow-inner">
          <div class="text-[11px] font-semibold text-slate-400 mb-1">Pairwise Cost / Distance Matrix (${n} × ${n})</div>
          <table class="border-collapse text-center text-xs font-mono w-full">
            <thead>
              <tr>
                <th class="p-1.5 text-slate-500 border border-slate-800">\\</th>
      `;
      for (let j = 0; j < n; j++) {
        html += `<th class="p-1.5 text-cyan-400 border border-slate-800 font-bold">${chr(65 + j)}</th>`;
      }
      html += `</tr></thead><tbody>`;

      for (let i = 0; i < n; i++) {
        html += `<tr><td class="p-1.5 text-cyan-400 border border-slate-800 font-bold">${chr(65 + i)}</td>`;
        for (let j = 0; j < n; j++) {
          const val = matrix[i][j];
          const isDiag = i === j;
          html += `<td class="p-1.5 border border-slate-800 ${isDiag ? 'bg-slate-900 text-slate-600' : 'text-slate-300'}">${val}</td>`;
        }
        html += `</tr>`;
      }
      html += `</tbody></table></div>`;
    }

    if (dataStructures.dp_table) {
      const rows = dataStructures.dp_table.length;
      const cols = dataStructures.dp_table[0] ? dataStructures.dp_table[0].length : 0;
      html += `
        <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs flex items-center justify-between">
          <span class="text-slate-400">Dynamic Programming Table Dimensions:</span>
          <span class="font-mono font-bold text-emerald-400">${rows} Rows × ${cols} Columns (${rows * cols} Subproblem Cells)</span>
        </div>
      `;
    }

    if (dataStructures.board_size) {
      const n = dataStructures.board_size;
      html += `
        <div class="grid grid-cols-2 gap-3 text-xs">
          <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
            <span class="text-slate-400 block mb-1">State Representation</span>
            <span class="font-mono text-cyan-400 font-bold">1D Array of Queen Columns: Q[0..${n-1}]</span>
          </div>
          <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
            <span class="text-slate-400 block mb-1">Constraint Bitmasks</span>
            <span class="font-mono text-emerald-400 font-bold">Cols (${n}), Diagonals (${2*n-1})</span>
          </div>
        </div>
      `;
    }

    html += `</div>`;
    this.container.innerHTML = html;
  }
}

function chr(code) {
  return String.fromCharCode(code);
}

window.DataStructureVisualizer = DataStructureVisualizer;
