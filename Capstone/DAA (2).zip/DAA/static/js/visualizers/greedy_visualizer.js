/**
 * Greedy Heuristic & Local Search Visualizer
 * Visualizes candidate item rankings, ratios, greedy selection queues, and capacity consumption.
 */

class GreedyVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.items = [];
    this.selectedIds = [];
    this.currentWeight = 0;
    this.currentValue = 0;
    this.capacity = 50;
    this.decision = null;
    this.activeItem = null;
  }

  setData(dataStructures, step) {
    if (dataStructures && dataStructures.sorted_items) {
      this.items = dataStructures.sorted_items;
    }

    if (step) {
      this.updateStep(step);
    } else {
      this.render();
    }
  }

  updateStep(step) {
    if (!step) return;

    if (step.sorted_items) {
      this.items = step.sorted_items;
    }
    if (step.current_weight !== undefined) {
      this.currentWeight = step.current_weight;
    }
    if (step.current_value !== undefined) {
      this.currentValue = step.current_value;
    }
    if (step.selected_items) {
      this.selectedIds = step.selected_items;
    }
    this.decision = step.decision || null;
    this.activeItem = step.item || null;

    this.render();
  }

  render() {
    if (!this.container) return;

    if (!this.items || this.items.length === 0) {
      this.container.innerHTML = `
        <div class="h-64 flex flex-col items-center justify-center text-slate-500 text-sm">
          <i class="fas fa-list-ol text-3xl mb-2 text-slate-600"></i>
          <p>Greedy Candidate List will render when Greedy Heuristic executes.</p>
        </div>
      `;
      return;
    }

    let html = `
      <div class="flex flex-col gap-4 w-full">
        <!-- Capacity / Value Status Bar -->
        <div class="grid grid-cols-3 gap-3 p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs">
          <div class="flex flex-col">
            <span class="text-slate-400">Total Value Achieved</span>
            <span class="text-base font-mono font-bold text-emerald-400">${this.currentValue}</span>
          </div>
          <div class="flex flex-col">
            <span class="text-slate-400">Weight Used</span>
            <span class="text-base font-mono font-bold text-cyan-400">${this.currentWeight}</span>
          </div>
          <div class="flex flex-col">
            <span class="text-slate-400">Items Selected</span>
            <span class="text-base font-mono font-bold text-amber-400">${this.selectedIds.length} / ${this.items.length}</span>
          </div>
        </div>

        <!-- Sorted Candidate Items Queue -->
        <div class="flex flex-col gap-2">
          <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Candidate Items (Sorted by Value/Weight Ratio)</span>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[360px] overflow-y-auto pr-1">
    `;

    this.items.forEach((it, idx) => {
      const isSelected = this.selectedIds.includes(it.id);
      const isActive = this.activeItem && this.activeItem.id === it.id;

      let cardStyle = 'border-slate-800 bg-slate-900/70 text-slate-300';
      let statusBadge = `<span class="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px]">Pending</span>`;

      if (isActive) {
        cardStyle = this.decision === 'ACCEPTED' ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200 glow-emerald' : 'border-rose-500 bg-rose-950/40 text-rose-200 glow-rose';
        statusBadge = this.decision === 'ACCEPTED' ? `<span class="px-2 py-0.5 rounded bg-emerald-900 text-emerald-300 text-[10px] font-bold">ACCEPTED</span>` : `<span class="px-2 py-0.5 rounded bg-rose-900 text-rose-300 text-[10px] font-bold">REJECTED</span>`;
      } else if (isSelected) {
        cardStyle = 'border-emerald-700 bg-emerald-950/30 text-emerald-300';
        statusBadge = `<span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px]">Included</span>`;
      }

      html += `
        <div class="p-2.5 rounded-lg border ${cardStyle} flex items-center justify-between transition-all">
          <div class="flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-mono text-slate-400 font-bold">${idx + 1}</span>
            <div>
              <div class="text-xs font-semibold">Item ${it.id + 1}</div>
              <div class="text-[11px] text-slate-400 font-mono">Weight: ${it.weight} | Value: ${it.value}</div>
            </div>
          </div>
          <div class="flex flex-col items-end gap-1">
            <span class="text-[11px] font-mono text-cyan-400 font-bold">Ratio: ${it.ratio}</span>
            ${statusBadge}
          </div>
        </div>
      `;
    });

    html += `</div></div></div>`;
    this.container.innerHTML = html;
  }
}

window.GreedyVisualizer = GreedyVisualizer;
