/**
 * N-Queens Chessboard Visualizer
 * Dynamic N x N grid with queen placement, conflict laser rays, forward checking domain badges, and backtrack animations.
 */

class ChessboardVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.boardSize = 8;
    this.boardState = []; // array of column indices for each row, or -1 if empty
    this.conflictInfo = null;
    this.candidateSquare = null;
    this.solutionCount = 0;
  }

  setData(dataStructures, step) {
    if (dataStructures && dataStructures.board_size) {
      this.boardSize = dataStructures.board_size;
      this.boardState = new Array(this.boardSize).fill(-1);
    }

    if (step) {
      this.updateStep(step);
    } else {
      this.render();
    }
  }

  updateStep(step) {
    if (!step) return;

    if (step.board_size) {
      this.boardSize = step.board_size;
    }

    if (step.current_board) {
      this.boardState = [...step.current_board];
      while (this.boardState.length < this.boardSize) {
        this.boardState.push(-1);
      }
    }

    this.conflictInfo = step.conflict || null;
    this.candidateSquare = step.candidate || (step.placed_queen ? step.placed_queen : null);
    if (step.solution_count !== undefined) {
      this.solutionCount = step.solution_count;
    }

    this.render();
  }

  render() {
    if (!this.container) return;

    const n = this.boardSize || 8;
    
    let html = `
      <div class="flex flex-col items-center justify-center gap-4 w-full">
        <!-- Chessboard Header HUD -->
        <div class="flex items-center justify-between w-full max-w-[480px] px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs">
          <div class="flex items-center gap-2">
            <span class="text-slate-400">Board Size:</span>
            <span class="font-mono font-bold text-cyan-400">${n} × ${n}</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-slate-400">Queens Placed:</span>
            <span class="font-mono font-bold text-emerald-400">${this.boardState.filter(c => c >= 0).length} / ${n}</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-slate-400">Solutions:</span>
            <span class="font-mono font-bold text-amber-400">${this.solutionCount}</span>
          </div>
        </div>

        <!-- Dynamic Chessboard Container -->
        <div class="relative p-3 bg-slate-900 border-2 border-slate-700 rounded-xl shadow-2xl">
          <div class="grid gap-1" style="grid-template-columns: repeat(${n}, minmax(0, 1fr)); width: min(420px, 80vw); aspect-ratio: 1;">
    `;

    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        const isDark = (r + c) % 2 === 1;
        const hasQueen = this.boardState[r] === c;
        
        let squareClass = `chess-square rounded flex items-center justify-center text-xl font-bold cursor-default select-none ${isDark ? 'dark' : 'light'} `;
        
        const isConflictTarget = this.candidateSquare && this.candidateSquare[0] === r && this.candidateSquare[1] === c && this.conflictInfo;
        const isAttacker = this.conflictInfo && this.conflictInfo.attacker && this.conflictInfo.attacker[0] === r && this.conflictInfo.attacker[1] === c;

        if (hasQueen) {
          squareClass += 'queen-active text-emerald-300 ';
        } else if (isConflictTarget) {
          squareClass += 'conflict-active text-rose-300 ';
        } else if (isAttacker) {
          squareClass += 'border-2 border-rose-500 text-amber-400 ';
        }

        html += `<div class="${squareClass}" data-row="${r}" data-col="${c}">`;
        if (hasQueen) {
          html += `<span>♛</span>`;
        } else if (isConflictTarget) {
          html += `<span class="text-rose-400 text-base">✕</span>`;
        }
        html += `</div>`;
      }
    }

    html += `</div></div>`;

    // Conflict Explanation Note
    if (this.conflictInfo) {
      html += `
        <div class="flex items-center gap-2 px-3 py-1.5 bg-rose-950/60 border border-rose-800/80 rounded text-rose-300 text-xs animate-pulse">
          <i class="fas fa-triangle-exclamation"></i>
          <span>Conflict detected: <b>${this.conflictInfo.type} attack</b> from Queen at Row ${this.conflictInfo.attacker[0]}, Col ${this.conflictInfo.attacker[1]}</span>
        </div>
      `;
    }

    html += `</div>`;
    this.container.innerHTML = html;
  }
}

window.ChessboardVisualizer = ChessboardVisualizer;
