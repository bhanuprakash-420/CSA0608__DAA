/**
 * Dynamic Programming (DP) Table Matrix Visualizer
 * Visualizes 2D Tabulation grids for 0/1 Knapsack and Boolean DP for Subset Sum.
 */

class DpVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.tableData = null;
    this.itemLabels = [];
    this.colLabels = [];
    this.activeCell = null;
    this.referencedCells = [];
    this.selectedCells = [];
    this.formulaText = '';
  }

  setData(dataStructures, step) {
    if (!dataStructures) return;
    this.tableData = dataStructures.dp_table || [];
    this.itemLabels = dataStructures.item_labels || [];
    this.colLabels = dataStructures.capacity_labels || dataStructures.sum_labels || [];

    if (step) {
      this.updateStep(step);
    } else {
      this.render();
    }
  }

  updateStep(step) {
    if (!step) return;

    if (step.dp_table) {
      this.tableData = step.dp_table;
    }

    this.activeCell = step.highlight ? { row: step.highlight.row, col: step.highlight.col } : null;
    this.referencedCells = (step.highlight && step.highlight.referenced) ? step.highlight.referenced : [];
    this.formulaText = step.formula || '';

    if (step.type === 'backtrack_solution' && step.highlight && step.highlight.selected) {
      this.selectedCells.push({ row: step.highlight.row, col: step.highlight.col });
    } else if (step.type === 'init') {
      this.selectedCells = [];
    }

    this.render();
  }

  render() {
    if (!this.container) return;

    if (!this.tableData || this.tableData.length === 0) {
      this.container.innerHTML = `
        <div class="h-64 flex flex-col items-center justify-center text-slate-500 text-sm">
          <i class="fas fa-table-cells text-3xl mb-2 text-slate-600"></i>
          <p>DP Matrix Table will render when Dynamic Programming algorithm executes.</p>
        </div>
      `;
      return;
    }

    const rows = this.tableData.length;
    const cols = this.tableData[0] ? this.tableData[0].length : 0;

    let html = `
      <div class="flex flex-col gap-3">
        <!-- Formula HUD Banner -->
        <div class="p-3 bg-slate-900 border border-cyan-900/50 rounded-lg flex items-center justify-between">
          <div class="flex items-center gap-2 text-xs">
            <span class="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 font-mono font-semibold">RECURRENCE</span>
            <span class="text-slate-300 font-mono">${this.formulaText || 'DP Table State Tabulation'}</span>
          </div>
          <div class="flex items-center gap-3 text-xs text-slate-400">
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-sky-600"></span> Active Cell</span>
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-emerald-700"></span> Referenced</span>
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-emerald-500"></span> Optimal Path</span>
          </div>
        </div>

        <!-- Scrollable Table Grid -->
        <div class="overflow-auto max-h-[480px] rounded-lg border border-slate-800 bg-slate-950 p-2 shadow-inner">
          <table class="border-collapse text-center mx-auto text-xs">
            <thead>
              <tr>
                <th class="sticky top-0 left-0 z-20 bg-slate-900 text-slate-400 p-2 border border-slate-800 font-semibold text-left">Items \\ Cap</th>
    `;

    for (let j = 0; j < cols; j++) {
      const label = this.colLabels[j] || `${j}`;
      html += `<th class="sticky top-0 z-10 bg-slate-900 text-slate-300 px-2 py-1.5 border border-slate-800 font-mono text-[11px]">${label}</th>`;
    }
    html += `</tr></thead><tbody>`;

    for (let i = 0; i < rows; i++) {
      const rowLabel = i === 0 ? "Base (0)" : (this.itemLabels[i - 1] || `Item ${i}`);
      html += `<tr>`;
      html += `<td class="sticky left-0 z-10 bg-slate-900 text-slate-300 px-2.5 py-1.5 border border-slate-800 font-medium text-left whitespace-nowrap text-[11px]">${rowLabel}</td>`;

      for (let j = 0; j < cols; j++) {
        const val = this.tableData[i][j];
        const displayVal = typeof val === 'boolean' ? (val ? 'T' : 'F') : val;

        let cellClass = 'dp-cell border border-slate-800/80 ';
        
        const isActive = this.activeCell && this.activeCell.row === i && this.activeCell.col === j;
        const isRef = this.referencedCells.some(c => c.row === i && c.col === j);
        const isSelected = this.selectedCells.some(c => c.row === i && c.col === j);

        if (isActive) {
          cellClass += 'highlight-active';
        } else if (isSelected) {
          cellClass += 'highlight-selected';
        } else if (isRef) {
          cellClass += 'highlight-ref';
        } else {
          cellClass += 'bg-slate-900/60 text-slate-300 hover:bg-slate-800';
        }

        html += `<td class="${cellClass}" title="Row: ${i}, Col: ${j}, Value: ${displayVal}">${displayVal}</td>`;
      }
      html += `</tr>`;
    }

    html += `</tbody></table></div></div>`;
    this.container.innerHTML = html;
  }
}

window.DpVisualizer = DpVisualizer;
