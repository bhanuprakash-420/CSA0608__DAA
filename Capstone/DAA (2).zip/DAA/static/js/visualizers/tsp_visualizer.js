/**
 * Interactive TSP 2D Graph Visualizer (Canvas-based)
 * Visualizes cities, distance matrices, active search paths, pruned edges, and optimal tours.
 */

class TspVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.canvas = null;
    this.ctx = null;
    this.matrix = [];
    this.coordinates = [];
    this.currentTour = [];
    this.bestTour = [];
    this.currentCost = 0;
    this.bestCost = null;
    this.activeCity = null;

    this.initCanvas();
  }

  initCanvas() {
    if (!this.container) return;
    this.container.innerHTML = '';

    const wrapper = document.createElement('div');
    wrapper.className = 'relative w-full h-full min-h-[420px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800';

    this.canvas = document.createElement('canvas');
    this.canvas.className = 'w-full h-full block';
    wrapper.appendChild(this.canvas);

    // Overlay Badge
    const overlay = document.createElement('div');
    overlay.className = 'absolute top-3 left-3 flex flex-col gap-1.5 bg-slate-900/85 backdrop-blur px-3.5 py-2.5 rounded-lg border border-slate-700 text-xs shadow-lg z-10';
    overlay.id = 'tsp-overlay-hud';
    overlay.innerHTML = `
      <div class="flex items-center gap-2">
        <span class="text-slate-400">Current Cost:</span>
        <span id="tsp-curr-cost" class="font-mono font-bold text-amber-400">0</span>
      </div>
      <div class="flex items-center gap-2">
        <span class="text-slate-400">Best Tour Cost:</span>
        <span id="tsp-best-cost" class="font-mono font-bold text-emerald-400">N/A</span>
      </div>
      <div class="flex items-center gap-2 text-[11px] text-slate-400 pt-1 border-t border-slate-800">
        <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Active Path</span>
        <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Best Tour</span>
      </div>
    `;
    wrapper.appendChild(overlay);

    this.container.appendChild(wrapper);
    this.ctx = this.canvas.getContext('2d');

    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());
  }

  resizeCanvas() {
    if (!this.canvas || !this.container) return;
    const rect = this.container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = (rect.width || 800) * dpr;
    this.canvas.height = (rect.height || 450) * dpr;
    this.ctx.scale(dpr, dpr);
    this.render();
  }

  setData(dataStructures, step) {
    if (!dataStructures) return;
    this.matrix = dataStructures.matrix || [];
    this.coordinates = dataStructures.coordinates || [];

    if (step) {
      this.updateStep(step);
    } else {
      this.render();
    }
  }

  updateStep(step) {
    if (!step) return;

    if (step.current_tour) {
      this.currentTour = step.current_tour;
      this.activeCity = this.currentTour[this.currentTour.length - 1];
    }
    if (step.current_cost !== undefined) {
      this.currentCost = step.current_cost;
    }
    if (step.best_tour) {
      this.bestTour = step.best_tour;
    }
    if (step.best_cost !== undefined) {
      this.bestCost = step.best_cost;
    }

    // Update overlay text
    const currCostEl = document.getElementById('tsp-curr-cost');
    const bestCostEl = document.getElementById('tsp-best-cost');
    if (currCostEl) currCostEl.textContent = `${this.currentCost}`;
    if (bestCostEl) bestCostEl.textContent = this.bestCost !== null && this.bestCost !== undefined ? `${this.bestCost}` : 'N/A';

    this.render();
  }

  render() {
    if (!this.ctx || !this.canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const width = this.canvas.width / dpr;
    const height = this.canvas.height / dpr;

    this.ctx.clearRect(0, 0, width, height);

    const n = this.coordinates.length;
    if (n === 0) {
      this.ctx.fillStyle = '#64748b';
      this.ctx.font = '14px Inter, sans-serif';
      this.ctx.textAlign = 'center';
      this.ctx.fillText('TSP Graph will render when problem instance is loaded.', width / 2, height / 2);
      return;
    }

    // Compute coordinate mapping to center the graph in the canvas
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    this.coordinates.forEach(c => {
      minX = Math.min(minX, c.x);
      maxX = Math.max(maxX, c.x);
      minY = Math.min(minY, c.y);
      maxY = Math.max(maxY, c.y);
    });

    const padding = 60;
    const rangeX = (maxX - minX) || 1;
    const rangeY = (maxY - minY) || 1;
    const scaleX = (width - padding * 2) / rangeX;
    const scaleY = (height - padding * 2) / rangeY;
    const scale = Math.min(scaleX, scaleY);

    const mapX = (x) => padding + (x - minX) * scale + (width - padding * 2 - rangeX * scale) / 2;
    const mapY = (y) => padding + (y - minY) * scale + (height - padding * 2 - rangeY * scale) / 2;

    // Draw all background pairwise edges (faint gray)
    this.ctx.strokeStyle = '#1e293b';
    this.ctx.lineWidth = 1;
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const u = this.coordinates[i];
        const v = this.coordinates[j];
        this.ctx.beginPath();
        this.ctx.moveTo(mapX(u.x), mapY(u.y));
        this.ctx.lineTo(mapX(v.x), mapY(v.y));
        this.ctx.stroke();

        // Edge distance label if small N
        if (n <= 6 && this.matrix[i] && this.matrix[i][j] !== undefined) {
          const midX = (mapX(u.x) + mapX(v.x)) / 2;
          const midY = (mapX(u.y) + mapY(v.y)) / 2;
          this.ctx.fillStyle = '#475569';
          this.ctx.font = '9px Fira Code, monospace';
          this.ctx.textAlign = 'center';
          this.ctx.fillText(`${this.matrix[i][j]}`, midX, midY);
        }
      }
    }

    // Draw Best Tour (Emerald glowing line)
    if (this.bestTour && this.bestTour.length > 1) {
      this.ctx.strokeStyle = '#10b981';
      this.ctx.lineWidth = 3.5;
      this.ctx.shadowColor = '#10b981';
      this.ctx.shadowBlur = 12;
      this.ctx.beginPath();
      for (let i = 0; i < this.bestTour.length; i++) {
        const cityIdx = this.bestTour[i];
        const c = this.coordinates[cityIdx];
        if (c) {
          const px = mapX(c.x);
          const py = mapY(c.y);
          if (i === 0) this.ctx.moveTo(px, py);
          else this.ctx.lineTo(px, py);
        }
      }
      this.ctx.stroke();
      this.ctx.shadowBlur = 0;
    }

    // Draw Current Tour (Amber animated path)
    if (this.currentTour && this.currentTour.length > 1) {
      this.ctx.strokeStyle = '#f59e0b';
      this.ctx.lineWidth = 2.5;
      this.ctx.shadowColor = '#f59e0b';
      this.ctx.shadowBlur = 10;
      this.ctx.beginPath();
      for (let i = 0; i < this.currentTour.length; i++) {
        const cityIdx = this.currentTour[i];
        const c = this.coordinates[cityIdx];
        if (c) {
          const px = mapX(c.x);
          const py = mapY(c.y);
          if (i === 0) this.ctx.moveTo(px, py);
          else this.ctx.lineTo(px, py);
        }
      }
      this.ctx.stroke();
      this.ctx.shadowBlur = 0;
    }

    // Draw City Nodes
    this.coordinates.forEach((c, idx) => {
      const px = mapX(c.x);
      const py = mapY(c.y);
      const isActive = idx === this.activeCity;
      const isStart = idx === 0;

      this.ctx.beginPath();
      this.ctx.arc(px, py, isActive ? 16 : 13, 0, Math.PI * 2);

      if (isActive) {
        this.ctx.fillStyle = '#f59e0b';
        this.ctx.shadowColor = '#f59e0b';
        this.ctx.shadowBlur = 15;
      } else if (isStart) {
        this.ctx.fillStyle = '#06b6d4';
        this.ctx.shadowBlur = 0;
      } else {
        this.ctx.fillStyle = '#0f172a';
        this.ctx.shadowBlur = 0;
      }
      this.ctx.fill();
      this.ctx.shadowBlur = 0;

      // Border
      this.ctx.strokeStyle = isActive ? '#fef3c7' : (isStart ? '#38bdf8' : '#334155');
      this.ctx.lineWidth = 2;
      this.ctx.stroke();

      // Text label
      this.ctx.fillStyle = isActive ? '#0f172a' : '#f8fafc';
      this.ctx.font = 'bold 10px Fira Code, monospace';
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      this.ctx.fillText(c.label ? c.label.replace('City ', '') : `${idx}`, px, py);
    });
  }
}

window.TspVisualizer = TspVisualizer;
