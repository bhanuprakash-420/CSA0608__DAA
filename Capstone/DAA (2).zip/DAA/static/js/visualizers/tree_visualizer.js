/**
 * Interactive Search Tree Visualizer (Canvas-based with Pan/Zoom & Node Details)
 * Visualizes State Space Trees for Backtracking and Branch & Bound algorithms.
 */

class TreeVisualizer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.canvas = null;
    this.ctx = null;
    this.nodes = [];
    this.activeNodeId = null;
    this.bestNodeId = null;
    this.prunedNodeIds = new Set();
    
    // Transform & Pan/Zoom
    this.scale = 1.0;
    this.offsetX = 0;
    this.offsetY = 0;
    this.isDragging = false;
    this.dragStartX = 0;
    this.dragStartY = 0;

    this.initCanvas();
  }

  initCanvas() {
    if (!this.container) return;
    this.container.innerHTML = '';
    
    const wrapper = document.createElement('div');
    wrapper.className = 'relative w-full h-full min-h-[420px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800';

    this.canvas = document.createElement('canvas');
    this.canvas.className = 'w-full h-full block cursor-grab';
    wrapper.appendChild(this.canvas);

    // Controls Overlay
    const controls = document.createElement('div');
    controls.className = 'absolute top-3 right-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-700 text-xs text-slate-300 z-10';
    controls.innerHTML = `
      <button id="tree-zoom-in" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-cyan-400 font-bold" title="Zoom In">+</button>
      <button id="tree-zoom-out" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-cyan-400 font-bold" title="Zoom Out">-</button>
      <button id="tree-reset" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-xs" title="Reset View"><i class="fas fa-expand"></i> Fit</button>
      <span class="text-slate-500">|</span>
      <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Active</span>
      <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Pruned</span>
      <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Best</span>
    `;
    wrapper.appendChild(controls);

    this.container.appendChild(wrapper);
    this.ctx = this.canvas.getContext('2d');

    // Resize handling
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    // Pan & Zoom Event Listeners
    this.canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.dragStartX = e.clientX - this.offsetX;
      this.dragStartY = e.clientY - this.offsetY;
      this.canvas.classList.add('cursor-grabbing');
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      this.offsetX = e.clientX - this.dragStartX;
      this.offsetY = e.clientY - this.dragStartY;
      this.render();
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
      if (this.canvas) this.canvas.classList.remove('cursor-grabbing');
    });

    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      this.scale = Math.max(0.2, Math.min(3.0, this.scale * zoomFactor));
      this.render();
    });

    document.getElementById('tree-zoom-in')?.addEventListener('click', () => {
      this.scale = Math.min(3.0, this.scale * 1.2);
      this.render();
    });
    document.getElementById('tree-zoom-out')?.addEventListener('click', () => {
      this.scale = Math.max(0.2, this.scale / 1.2);
      this.render();
    });
    document.getElementById('tree-reset')?.addEventListener('click', () => {
      this.resetView();
    });
  }

  resizeCanvas() {
    if (!this.canvas || !this.container) return;
    const rect = this.container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = (rect.width || 800) * dpr;
    this.canvas.height = (rect.height || 450) * dpr;
    this.ctx.scale(dpr, dpr);
    this.render();
  }

  resetView() {
    this.scale = 1.0;
    this.offsetX = (this.canvas.width / (window.devicePixelRatio || 1)) / 2 - 200;
    this.offsetY = 40;
    this.render();
  }

  setData(dataStructures, step) {
    if (!dataStructures) return;
    const rawNodes = dataStructures.tree_nodes || [];
    this.processTreeLayout(rawNodes);

    if (step) {
      this.updateStep(step);
    } else {
      this.render();
    }
  }

  processTreeLayout(rawNodes) {
    if (!rawNodes || rawNodes.length === 0) {
      this.nodes = [];
      return;
    }

    // Build tree map
    const nodeMap = new Map();
    rawNodes.forEach(n => {
      nodeMap.set(n.id, {
        ...n,
        children: [],
        x: 0,
        y: 0,
        radius: 18
      });
    });

    let root = null;
    rawNodes.forEach(n => {
      const node = nodeMap.get(n.id);
      if (n.parent_id !== null && nodeMap.has(n.parent_id)) {
        nodeMap.get(n.parent_id).children.push(node);
      } else if (!root) {
        root = node;
      }
    });

    if (!root && rawNodes.length > 0) root = nodeMap.get(rawNodes[0].id);
    if (!root) return;

    // Compute coordinates using recursive breadth layout
    let currentX = 50;
    const levelHeight = 65;

    function assignPositions(node, depth) {
      node.y = depth * levelHeight + 40;
      if (node.children.length === 0) {
        node.x = currentX;
        currentX += 55;
      } else {
        node.children.forEach(c => assignPositions(c, depth + 1));
        const first = node.children[0];
        const last = node.children[node.children.length - 1];
        node.x = (first.x + last.x) / 2;
      }
    }

    assignPositions(root, 0);
    this.nodes = Array.from(nodeMap.values());
    this.resetView();
  }

  updateStep(step) {
    if (!step) return;

    if (step.node_id !== undefined) {
      this.activeNodeId = step.node_id;
    } else if (step.tree_node) {
      this.activeNodeId = step.tree_node.id;
    }

    if (step.action && step.action.includes('prune')) {
      if (this.activeNodeId !== null) this.prunedNodeIds.add(this.activeNodeId);
    }

    if (step.action && step.action.includes('best')) {
      this.bestNodeId = this.activeNodeId;
    }

    this.render();
  }

  render() {
    if (!this.ctx || !this.canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const width = this.canvas.width / dpr;
    const height = this.canvas.height / dpr;

    this.ctx.clearRect(0, 0, width, height);

    if (this.nodes.length === 0) {
      this.ctx.fillStyle = '#64748b';
      this.ctx.font = '14px Inter, sans-serif';
      this.ctx.textAlign = 'center';
      this.ctx.fillText('Search Tree will render when Backtracking or Branch & Bound algorithm runs.', width / 2, height / 2);
      return;
    }

    this.ctx.save();
    this.ctx.translate(this.offsetX, this.offsetY);
    this.ctx.scale(this.scale, this.scale);

    // Draw Edges first
    this.nodes.forEach(node => {
      if (node.parent_id !== null) {
        const parent = this.nodes.find(n => n.id === node.parent_id);
        if (parent) {
          this.ctx.beginPath();
          this.ctx.moveTo(parent.x, parent.y);
          this.ctx.lineTo(node.x, node.y);

          const isPrunedEdge = this.prunedNodeIds.has(node.id);
          this.ctx.strokeStyle = isPrunedEdge ? '#e11d48' : '#334155';
          this.ctx.lineWidth = isPrunedEdge ? 1.5 : 1.2;
          if (isPrunedEdge) this.ctx.setLineDash([4, 3]);
          else this.ctx.setLineDash([]);
          this.ctx.stroke();
          this.ctx.setLineDash([]);

          // Edge Branch Label
          if (node.branch) {
            const midX = (parent.x + node.x) / 2;
            const midY = (parent.y + node.y) / 2;
            this.ctx.fillStyle = '#94a3b8';
            this.ctx.font = '9px Fira Code, monospace';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(node.branch.slice(0, 10), midX, midY - 3);
          }
        }
      }
    });

    // Draw Nodes
    this.nodes.forEach(node => {
      const isActive = node.id === this.activeNodeId;
      const isPruned = this.prunedNodeIds.has(node.id) || (node.status && node.status.includes('prune'));
      const isBest = node.id === this.bestNodeId || (node.status && node.status.includes('best'));

      this.ctx.beginPath();
      this.ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);

      if (isActive) {
        this.ctx.fillStyle = '#06b6d4'; // Cyan
        this.ctx.shadowColor = '#06b6d4';
        this.ctx.shadowBlur = 15;
      } else if (isPruned) {
        this.ctx.fillStyle = '#be123c'; // Rose
        this.ctx.shadowBlur = 0;
      } else if (isBest) {
        this.ctx.fillStyle = '#059669'; // Emerald
        this.ctx.shadowColor = '#10b981';
        this.ctx.shadowBlur = 12;
      } else {
        this.ctx.fillStyle = '#1e293b'; // Slate
        this.ctx.shadowBlur = 0;
      }

      this.ctx.fill();
      this.ctx.shadowBlur = 0;

      // Border
      this.ctx.strokeStyle = isActive ? '#a5f3fc' : (isPruned ? '#f43f5e' : (isBest ? '#34d399' : '#475569'));
      this.ctx.lineWidth = isActive ? 2.5 : 1.5;
      this.ctx.stroke();

      // Node Label (ID or Value)
      this.ctx.fillStyle = isActive ? '#0f172a' : '#f8fafc';
      this.ctx.font = 'bold 10px Fira Code, monospace';
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      
      const label = node.upper_bound !== undefined ? `${Math.round(node.upper_bound)}` : `${node.id}`;
      this.ctx.fillText(label, node.x, node.y);

      // Scissor icon or cross on pruned node
      if (isPruned) {
        this.ctx.fillStyle = '#ffe4e6';
        this.ctx.font = '10px sans-serif';
        this.ctx.fillText('✂', node.x + 14, node.y - 12);
      }
    });

    this.ctx.restore();
  }
}

window.TreeVisualizer = TreeVisualizer;
