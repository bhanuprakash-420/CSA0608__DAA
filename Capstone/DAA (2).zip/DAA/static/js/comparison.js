/**
 * Multi-Algorithm Comparison Suite
 * Evaluates multiple algorithms head-to-head on identical problem instances and renders comparative Chart.js graphs.
 */

class ComparisonSuite {
  constructor() {
    this.timeChart = null;
    this.memoryChart = null;
    this.statesChart = null;
    this.qualityChart = null;
    this.comparisonData = null;

    this.initEventListeners();
  }

  initEventListeners() {
    document.getElementById('btn-run-comparison')?.addEventListener('click', () => this.executeComparison());
    document.getElementById('btn-export-comparison-pdf')?.addEventListener('click', () => this.exportComparisonPdf());
  }

  async executeComparison() {
    const problem = AppState.currentProblem;
    const params = AppState.currentInputParams;

    // Get checked algorithms
    const checkboxes = document.querySelectorAll('.compare-algo-checkbox:checked');
    const algorithms = Array.from(checkboxes).map(cb => cb.value);

    if (algorithms.length < 2) {
      alert('Please select at least 2 algorithms to compare.');
      return;
    }

    const btn = document.getElementById('btn-run-comparison');
    const spinner = document.getElementById('compare-spinner');
    if (btn) btn.disabled = true;
    if (spinner) spinner.classList.remove('hidden');

    try {
      const data = await API.compare(problem, algorithms, params);
      this.comparisonData = data;
      this.renderResults(data);
    } catch (err) {
      alert(`Comparison failed: ${err.message}`);
    } finally {
      if (btn) btn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
    }
  }

  renderResults(data) {
    const results = data.results || [];
    if (results.length === 0) return;

    // Update Comparison Table
    const tbody = document.getElementById('comparison-table-body');
    if (tbody) {
      tbody.innerHTML = '';
      results.forEach(res => {
        const stats = res.statistics || {};
        const sol = res.solution || {};
        
        let objValue = '-';
        if (sol.total_value !== undefined) objValue = `Val: ${sol.total_value}`;
        else if (sol.total_distance !== undefined) objValue = `Dist: ${sol.total_distance}`;
        else if (sol.achieved_sum !== undefined) objValue = `Sum: ${sol.achieved_sum}`;
        else if (sol.total_solutions_found !== undefined) objValue = `Sols: ${sol.total_solutions_found}`;

        const isFastest = res.algorithm_name === data.comparison_summary.fastest_algorithm;

        const row = document.createElement('tr');
        row.className = 'border-b border-slate-800 hover:bg-slate-800/40 text-xs';
        row.innerHTML = `
          <td class="p-3 font-semibold text-slate-200 flex items-center gap-2">
            ${isFastest ? '<span class="text-amber-400" title="Fastest Algorithm"><i class="fas fa-trophy"></i></span>' : ''}
            ${res.algorithm_name}
          </td>
          <td class="p-3 font-mono ${isFastest ? 'text-amber-400 font-bold' : 'text-slate-300'}">${stats.execution_time_ms.toFixed(3)} ms</td>
          <td class="p-3 font-mono text-cyan-400">${stats.memory_kb.toFixed(2)} KB</td>
          <td class="p-3 font-mono text-slate-300">${stats.states_explored}</td>
          <td class="p-3 font-mono text-rose-400">${stats.states_pruned}</td>
          <td class="p-3 font-mono text-emerald-400 font-bold">${objValue}</td>
          <td class="p-3">
            <span class="px-2 py-0.5 rounded text-[11px] font-bold ${res.is_optimal ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}">
              ${res.is_optimal ? 'Optimal (Guaranteed)' : 'Approximate'}
            </span>
          </td>
        `;
        tbody.appendChild(row);
      });
    }

    // Render Charts
    this.renderCharts(results);

    // Show Results Section
    const resultsSec = document.getElementById('comparison-results-section');
    if (resultsSec) resultsSec.classList.remove('hidden');
  }

  renderCharts(results) {
    const labels = results.map(r => r.algorithm_name);
    const times = results.map(r => r.statistics.execution_time_ms);
    const memory = results.map(r => r.statistics.memory_kb);
    const explored = results.map(r => r.statistics.states_explored);
    const pruned = results.map(r => r.statistics.states_pruned);

    // Chart 1: Execution Time
    const ctxTime = document.getElementById('chart-comparison-time')?.getContext('2d');
    if (ctxTime) {
      if (this.timeChart) this.timeChart.destroy();
      this.timeChart = new Chart(ctxTime, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Execution Time (ms)',
            data: times,
            backgroundColor: 'rgba(6, 182, 212, 0.7)',
            borderColor: '#06b6d4',
            borderWidth: 1.5,
            borderRadius: 6
          }]
        },
        options: this.getChartOptions('Execution Time (ms)')
      });
    }

    // Chart 2: Memory Usage
    const ctxMem = document.getElementById('chart-comparison-memory')?.getContext('2d');
    if (ctxMem) {
      if (this.memoryChart) this.memoryChart.destroy();
      this.memoryChart = new Chart(ctxMem, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Memory Usage (KB)',
            data: memory,
            backgroundColor: 'rgba(139, 92, 246, 0.7)',
            borderColor: '#8b5cf6',
            borderWidth: 1.5,
            borderRadius: 6
          }]
        },
        options: this.getChartOptions('Memory (KB)')
      });
    }

    // Chart 3: Explored vs Pruned States
    const ctxStates = document.getElementById('chart-comparison-states')?.getContext('2d');
    if (ctxStates) {
      if (this.statesChart) this.statesChart.destroy();
      this.statesChart = new Chart(ctxStates, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            {
              label: 'States Explored',
              data: explored,
              backgroundColor: 'rgba(16, 185, 129, 0.7)',
              borderColor: '#10b981',
              borderWidth: 1.5,
              borderRadius: 6
            },
            {
              label: 'States Pruned',
              data: pruned,
              backgroundColor: 'rgba(244, 63, 94, 0.7)',
              borderColor: '#f43f5e',
              borderWidth: 1.5,
              borderRadius: 6
            }
          ]
        },
        options: this.getChartOptions('State Count')
      });
    }
  }

  getChartOptions(yAxisTitle) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } },
        tooltip: {
          backgroundColor: '#0f172a',
          titleColor: '#f8fafc',
          bodyColor: '#cbd5e1',
          borderColor: '#334155',
          borderWidth: 1
        }
      },
      scales: {
        x: {
          ticks: { color: '#94a3b8', font: { family: 'Inter', size: 10 } },
          grid: { color: 'rgba(51, 65, 85, 0.3)' }
        },
        y: {
          title: { display: true, text: yAxisTitle, color: '#94a3b8', font: { size: 11 } },
          ticks: { color: '#94a3b8', font: { family: 'Fira Code', size: 10 } },
          grid: { color: 'rgba(51, 65, 85, 0.3)' }
        }
      }
    };
  }

  async exportComparisonPdf() {
    if (!this.comparisonData) return;
    try {
      const payload = {
        problem: this.comparisonData.problem,
        problem_name: this.comparisonData.problem,
        input_params: AppState.currentInputParams,
        algorithms: this.comparisonData.results.map(r => r.algorithm_name),
        results: this.comparisonData.results
      };
      await API.downloadPdfReport(payload);
    } catch (err) {
      alert(`PDF download failed: ${err.message}`);
    }
  }
}

window.ComparisonSuite = ComparisonSuite;
